#property strict
#property version "2.00"
#property description "Modelo D integrado: diario, conciliacao e intencoes persistentes. Transporte ausente."
#include "ModeloD_Observer.mqh"
#include "ModeloD_Chart.mqh"
#include "ModeloD_StreamTerminal.mqh"
#include "ModeloD_Retry132.mqh"
#include "ModeloD_OperationalTerminal.mqh"
input int Instancia=1;
input int VolumePorNivel=1;
// Default approved volume 1; the later principal backtest uses 5.
input int IntervaloSegundos=2;
MDObserver615 obs615;MDStream615 stream615;MDRetry132 retry132;
MDOpState operational;MDOpSnapshot inventory_a,inventory_b;MDOpClock opclock;
MDOpTrail pending_trail[MDOP_LEVELS],position_trail[MDOP_POSITIONS];
bool pending_trail_started[MDOP_LEVELS],position_trail_started[MDOP_POSITIONS];
MDOpTrail live_trail;bool live_started=false;
int lock615=INVALID_HANDLE,report615=INVALID_HANDLE;
bool owns615=false,fatal=false,report_error=false;
string ledger="",ledger_path="",last_status="",stream_status615="AGUARDANDO_DADOS";
long transactions=0;
bool stream_started615=false,stream_failed615=false;
int stream_retries615=0;long stream_reported615=-1;
bool marker_loaded615=false,marker_restored615=false;long marker_saved_cursor615=-1;
string marker_text615="",marker_path615="";
enum MDMode615 {DADOS_ATUAIS=0};const MDMode615 Modo=DADOS_ATUAIS;
string Scope615(){return MDContext612(AccountInfoInteger(ACCOUNT_LOGIN),AccountInfoString(ACCOUNT_SERVER),Instancia);}
void Report615(string text) {
 Print(text);
 if(report615==INVALID_HANDLE)return;
 ResetLastError();uint n=FileWriteString(report615,TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS)+";"+text+"\r\n");
 FileFlush(report615);if(n==0||GetLastError()!=0)report_error=true;
}
void Status(string text) {
 Comment("MODELO D 2.00 — TRANSPORTE DESATIVADO\n",text,"\n",stream_status615,
 "\nIntencao nao e tentativa; resposta nao e execucao.\n",ledger_path);
 if(text!=last_status){last_status=text;Report615(text);}
}
void TouchSummary615()
{
 string names[5]={"S38,2","S50","S61,8","R38,2","R61,8"};
 for(int i=0;i<5;i++)
 {
  MDTouchAudit t=stream615.audit.touches[i];MDLevel level=stream615.control.day.levels[i];
  Report615("TOQUE_6_15;data="+IntegerToString(stream615.data.date)+";contrato="+stream615.data.contract+
   ";nivel="+names[i]+";estado="+(t.tape.touched?"TOQUE_OBSERVADO":"SEM_TOQUE_NO_TRECHO_CONFERIDO")+
   ";primeiro_msc="+IntegerToString(t.tape.first_msc)+";last_anterior="+DoubleToString(t.previous_at_touch,6)+
   ";last_atual="+DoubleToString(t.last_at_touch,6)+";indice="+IntegerToString(t.index_at_touch)+
   ";entrada_matematica="+DoubleToString(level.entry,6)+";entrada_tick="+DoubleToString(level.entry_tick,0)+
   ";abertura_valida="+IntegerToString(level.valid_open?1:0)+";geometria_bloqueada="+IntegerToString(level.geometry_blocked?1:0)+
   ";ate_exclusivo_msc="+IntegerToString(stream615.cursor)+";NAO_E_EXECUCAO;SEM_ORDENS");
 }
}
void Pump615()
{
 if(!owns615||!obs615.visible||!obs615.frozen||obs615.conflict||obs615.identity_changed)return;
 if(Modo!=DADOS_ATUAIS){stream_status615="TICKS: REPRODUCAO FIXA SOMENTE VISUAL";return;}
 if(!stream_started615||stream615.data.date!=obs615.data.date)
 {
  MDReset132(retry132);
  stream_started615=MDStreamStart615(stream615,obs615.data);
  marker_loaded615=false;marker_restored615=false;marker_saved_cursor615=-1;marker_text615="";
  marker_path615="ModeloD_OBSERVADO_615N_"+Scope615()+"_"+IntegerToString(obs615.data.date)+".dat";
  stream_failed615=!stream_started615;stream_retries615=0;stream_reported615=-1;
  Report615("TICKS_6_15_INICIO;data="+IntegerToString(obs615.data.date)+";contrato="+obs615.data.contract+";SEM_ORDENS");
 }
 if(stream_failed615){stream_status615="TICKS: BLOQUEADO — ENVIAR RELATORIO";return;}
 if(!MDDaySameData(stream615.data,obs615.data))
 {stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;DADOS_MUDARAM;SEM_ORDENS");return;}
 if(MDExpired132(retry132,(long)GetTickCount64()))
 {stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;RECUPERACAO_EXPIRADA_10_MIN;SEM_ORDENS");return;}
 if(!TerminalInfoInteger(TERMINAL_CONNECTED)){stream_status615="TICKS: SEM CONEXAO";return;}
 if(!MDDue132(retry132,(long)GetTickCount64()))return;
 MqlTick latest;
 if(!SymbolInfoTick(stream615.data.contract,latest)||latest.time_msc<stream615.audit.begin_msc)
 {stream_status615="TICKS: AGUARDANDO COTACAO DA SESSAO";return;}
 long target=MDStreamHorizon615(latest.time_msc,stream615.cutoff);
 if(target<stream615.cursor)
 {stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;TEMPO_REGREDIU;SEM_ORDENS");return;}
 // No maximo dois blocos por evento; nenhuma espera Sleep nem loop ate o presente.
 for(int b=0;b<2&&stream615.cursor<target&&!IsStopped();b++)
 {
  long end=stream615.cursor+299999;if(end>=target)end=target-1;
  if(retry132.active)end=retry132.end; // Reconsulta exatamente o bloco rejeitado.
  stream_reported615=-1; // Nenhum checkpoint/conciliacao enquanto falta este bloco.
  MDStream615 candidate=stream615;string why;
  if(!MDStreamCollect615(candidate,end,why,true))
  {
   if(IsStopped())return;
   if(StringFind(why,"TICKS_DIVERGEM_M1;")==0)
   {
    bool waiting=MDFail132(retry132,stream615.cursor,end,(long)GetTickCount64());
    Report615("TICKS_6_15_RECUPERACAO;tentativa="+IntegerToString(retry132.failures)+";nova_consulta_em_s=30;limite_s=600;motivo="+why+";SEM_ORDENS");
    if(!waiting){stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;RECUPERACAO_EXPIRADA_OU_JANELA_DIVERGENTE;SEM_ORDENS");}
    stream_status615="TICKS: RECUPERACAO PENDENTE — SEM APROVAR BLOCO";return;
   }
   stream_retries615++;
   Report615("TICKS_6_15_RETRY;tentativa="+IntegerToString(stream_retries615)+";de_msc="+IntegerToString(stream615.cursor)+";motivo="+why+";SEM_ORDENS");
   if(stream_retries615>=3){stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;TRES_TENTATIVAS_SEM_BLOCO_VALIDO;SEM_ORDENS");}
   stream_status615=stream_failed615?"TICKS: BLOQUEADO — ENVIAR RELATORIO":"TICKS: AGUARDANDO NOVA TENTATIVA";return;
  }
  if(!MDCanCommit132(retry132,stream615.cursor,end,(long)GetTickCount64()))
  {stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;RECUPERACAO_FORA_DO_PRAZO;SEM_ORDENS");return;}
  if(retry132.active)Report615("TICKS_6_15_RECUPERADO;de_msc="+IntegerToString(stream615.cursor)+";ate_msc="+IntegerToString(end)+";M1_DISPONIVEL_CONFERIDO;SEM_ORDENS");
  MDReset132(retry132);
  if(!MDObserverIdentity615(obs615,Scope615()))
  {MDVisualClear(0,(uint)Instancia);stream_failed615=true;Report615("TICKS_6_15_BLOQUEADO;IDENTIDADE_MUDOU;SEM_ORDENS");return;}
  bool new_touch=false;
  for(int i=0;i<5;i++)if(candidate.audit.touches[i].tape.touched&&!stream615.audit.touches[i].tape.touched)new_touch=true;
  stream615=candidate;stream_retries615=0;
  Report615("COBERTURA_615N;"+why+";SEM_ORDENS");
  Report615("TICKS_6_15_PROGRESSO;blocos="+IntegerToString(stream615.blocks)+";ticks="+IntegerToString(stream615.audit.count)+
   ";ate_exclusivo="+TimeToString((datetime)(stream615.cursor/1000),TIME_DATE|TIME_SECONDS)+";M1_DISPONIVEL_CONFERIDO;SEM_ORDENS");
  if(new_touch)TouchSummary615();
 }
 if(stream615.cursor==target&&stream615.audit.count>0)
 {
  stream_status615="TICKS: CONFERIDOS ATE "+TimeToString((datetime)(target/1000),TIME_SECONDS)+" (exclusivo)";
  if(stream_reported615!=target)
  {
   Report615("TICKS_6_15_ATUALIZADO;data="+IntegerToString(stream615.data.date)+";contrato="+stream615.data.contract+
    ";ate_exclusivo="+TimeToString((datetime)(target/1000),TIME_DATE|TIME_SECONDS)+";ticks="+IntegerToString(stream615.audit.count)+
    ";abertura_confere=1;M1_consistente=1;INTEGRIDADE_TOTAL_NAO_CERTIFICADA;SEM_ORDENS");
   TouchSummary615();stream_reported615=target;
  }
 }
 else stream_status615="TICKS: RECONSTRUINDO DESDE A ABERTURA";
}

string DataIdentity(const MDDataEvidence &d) {
 return IntegerToString(d.date)+"_"+d.contract+"_"+IntegerToString(d.open_msc)+"_"+
 DoubleToString(d.values.high_prev,16)+"_"+DoubleToString(d.values.low_prev,16)+"_"+
 DoubleToString(d.values.close_prev,16)+"_"+DoubleToString(d.values.open_today,16)+"_"+
 DoubleToString(d.values.adjustment,16)+"_"+DoubleToString(d.previous_adjustment,16)+"_"+
 IntegerToString(d.session.scheduled_open)+"_"+IntegerToString(d.session.cutoff)+"_"+
 IntegerToString(d.session.normal_end)+"_"+IntegerToString(d.expiry_date)+"_"+IntegerToString(d.source_date);
}
bool Commit(const MDOpState &next,string event) {
 if(MDOpEncode(next)==MDOpEncode(operational))return true;
 MDOpState candidate=next;if(opclock.ok&&opclock.utc>candidate.watermark)candidate.watermark=opclock.utc;
 string why;
 if(!MDOpCommitFile(ledger_path,lock615,ledger,operational,candidate,event,why)){
  fatal=true;Status("PERSISTENCIA_BLOQUEADA;"+why+";PRESERVAR_ARQUIVOS");return false;
 }
 Report615("COMMIT;revision="+IntegerToString(operational.revision)+";event="+event+";transporte=0");
 for(int i=0;i<operational.nlevels;i++){
  MDOpLevel l=operational.levels[i];
  Report615("LEVEL;key="+IntegerToString(l.key)+";symbol="+l.symbol+";origin="+IntegerToString(l.order)+
   ";accepted_server_msc="+IntegerToString(l.accepted_server)+";first_touch_server_msc="+IntegerToString(l.touch_server)+
   ";consumed="+IntegerToString(l.consumed?1:0)+";cutoff="+IntegerToString(l.cutoff?1:0)+";entry_math="+DoubleToString(l.prices.entry,16)+
   ";entry_requested="+DoubleToString(l.prices.entry_tick,0)+";SL_fixed="+DoubleToString(l.prices.sl_tick,0)+";TP_fixed="+DoubleToString(l.prices.tp_tick,0)+
   ";entry_phase="+IntegerToString(l.entry.phase)+";entry_attempt="+IntegerToString(l.entry.serial)+";cancel_phase="+IntegerToString(l.cancellation.phase));
 }
 for(int i=0;i<operational.npositions;i++){
  MDOpPosition v=operational.positions[i];
  Report615("POSITION;identifier="+IntegerToString(v.identifier)+";ticket="+IntegerToString(v.ticket)+";entered="+DoubleToString(v.entered,8)+
   ";exited="+DoubleToString(v.exited,8)+";residual="+DoubleToString(v.volume,8)+";SL_observed="+DoubleToString(v.sl,8)+";TP_observed="+DoubleToString(v.tp,8)+
   ";protection_attempt="+IntegerToString(v.protect.serial)+";close_phase="+IntegerToString(v.close.phase));
 }
 return true;
}
void Daily() {
 obs615.visible=false;
 if(!opclock.ok||opclock.offset!=-10800){stream_status615="DADOS: FUSO_SERVIDOR_B3_NAO_CONFIRMADO";MDVisualClear(0,(uint)Instancia);return;}
 int date=MDDateValue614((datetime)(opclock.utc/1000-10800));MDDailyRaw614 raw;string why;
 bool read=MDCollectDaily614(date,raw,why);
 if(!MDObserverUpdate615(obs615,date,read,raw,why)){
  stream_status615="DADOS: "+obs615.reason;MDVisualClear(0,(uint)Instancia);
  if(obs615.conflict){MDOpState conflict=operational;for(int i=0;i<conflict.nlevels;i++)if(conflict.levels[i].date==date)conflict.levels[i].conflict=true;Commit(conflict,"DAILY_CONFLICT");}
  return;
 }
 MDOpState next=operational;
 long cutoff=MDCivilMidnight2026(date)+(long)obs615.data.session.cutoff*1000+10800000;
 bool added=MDOpAddDay(next,date,obs615.data.contract,DataIdentity(obs615.data),obs615.control.day,obs615.data.open_msc,cutoff,VolumePorNivel,why);
 if(!Commit(next,added?"DAILY_DATA":"DAILY_CONFLICT"))return;
 if(!added){stream_status615="DADOS: "+why;return;}
 datetime begin=(datetime)(MDCivilMidnight2026(date)/1000+obs615.data.session.scheduled_open);
 datetime end=(datetime)(MDCivilMidnight2026(date)/1000+obs615.data.session.cutoff);
 if(!MDVisualSync(0,(uint)Instancia,obs615.control.day,begin,end,true)){Report615("VISUAL_SYNC_FAILED");}
 Pump615();
}
bool EntryProperties(const MDOpLevel &l) {
 double tick=0,minvol=0,maxvol=0,step=0,ask=0,bid=0,point=0;long mode=0,orders=0,stops=0,freeze=0;
 if(!SymbolInfoDouble(l.symbol,SYMBOL_TRADE_TICK_SIZE,tick)||tick!=5||
 !SymbolInfoDouble(l.symbol,SYMBOL_VOLUME_MIN,minvol)||!SymbolInfoDouble(l.symbol,SYMBOL_VOLUME_MAX,maxvol)||
 !SymbolInfoDouble(l.symbol,SYMBOL_VOLUME_STEP,step)||!SymbolInfoInteger(l.symbol,SYMBOL_TRADE_MODE,mode)||
 !SymbolInfoInteger(l.symbol,SYMBOL_ORDER_MODE,orders)||!SymbolInfoInteger(l.symbol,SYMBOL_TRADE_STOPS_LEVEL,stops)||
 !SymbolInfoInteger(l.symbol,SYMBOL_TRADE_FREEZE_LEVEL,freeze)||!SymbolInfoDouble(l.symbol,SYMBOL_POINT,point)||
 !SymbolInfoDouble(l.symbol,SYMBOL_ASK,ask)||!SymbolInfoDouble(l.symbol,SYMBOL_BID,bid))return false;
 MDExecGate613 g;g.volume_min=minvol;g.volume_max=maxvol;g.volume_step=step;
 if(!MDVolume613(l.volume,g)||(orders&SYMBOL_ORDER_LIMIT)==0||(orders&SYMBOL_ORDER_SL)==0||(orders&SYMBOL_ORDER_TP)==0)return false;
 if(mode!=SYMBOL_TRADE_MODE_FULL&&(l.prices.buy?mode!=SYMBOL_TRADE_MODE_LONGONLY:mode!=SYMBOL_TRADE_MODE_SHORTONLY))return false;
 double distance=(double)stops*point;
 if(l.prices.buy?ask-l.prices.entry_tick<distance:l.prices.entry_tick-bid<distance)return false;
 if(MathAbs(l.prices.entry_tick-l.prices.sl_tick)<distance||MathAbs(l.prices.entry_tick-l.prices.tp_tick)<distance)return false;
 double margin=0;if(!OrderCalcMargin(l.prices.buy?ORDER_TYPE_BUY:ORDER_TYPE_SELL,l.symbol,l.volume,l.prices.entry_tick,margin)||
 margin>AccountInfoDouble(ACCOUNT_MARGIN_FREE))return false;
 return true;
}
void BuildFrame(MDOpFrame &f,bool stable) {
 MDOpFrameReset(f,opclock.utc,opclock.server,opclock.ok,(bool)TerminalInfoInteger(TERMINAL_CONNECTED));f.stable=stable;
 bool current=obs615.visible&&stream_started615&&!stream_failed615&&!retry132.active&&
 stream_reported615==stream615.cursor&&stream615.data.date==obs615.data.date;
 bool live=false;string why;
 // Prove current Last coverage beyond the closed-minute stream, never reuse a stale minute as "now".
 if(current&&opclock.server>=stream615.cursor&&opclock.server-stream615.cursor<=60000) {
  if(!live_started||live_trail.symbol!=stream615.data.contract||live_trail.begin!=stream615.cursor-1){
   MDOpTrailInit(live_trail,stream615.data.contract,stream615.cursor-1,stream615.control.day.levels[0]);live_started=true;
  }
  live=MDOpTrailRead(live_trail,opclock.server,why);
 }
 for(int k=0;k<operational.nlevels;k++) {
  MDOpLevel l=operational.levels[k];
  if(current&&l.date==stream615.data.date&&l.symbol==stream615.data.contract) {
   MDTap tap=stream615.audit.touches[l.level].tape;
   f.touched[k]=tap.touched;f.first_touch[k]=tap.touched?tap.first_msc:0;
   // Independent short raw tail for each entry reference (the level-0 trail is only a coverage check).
   if(live&&opclock.server>stream615.cursor) {
    MqlTick ticks[];ResetLastError();int n=CopyTicksRange(l.symbol,ticks,COPY_TICKS_TRADE,(ulong)stream615.cursor,(ulong)(opclock.server-1));
    int error=GetLastError();long previous=stream615.audit.last_msc;double last=stream615.audit.last_price;
    bool valid=n>=0&&error==0&&n<=500000;
    for(int j=0;valid&&j<n;j++) {
     if(ticks[j].time_msc<stream615.cursor||ticks[j].time_msc>=opclock.server||ticks[j].time_msc<previous||!MDPositive(ticks[j].last)||
       (ticks[j].flags&(TICK_FLAG_LAST|TICK_FLAG_VOLUME|TICK_FLAG_BUY|TICK_FLAG_SELL))==0){valid=false;break;}
     if(!f.touched[k]&&MDCrossed(last,ticks[j].last,l.prices.entry)){f.touched[k]=true;f.first_touch[k]=ticks[j].time_msc;}
     last=ticks[j].last;previous=ticks[j].time_msc;
    }
    if(!valid)live=false;
   }
   f.entry_ready[k]=live&&opclock.offset==-10800&&EntryProperties(l)&&!f.touched[k]&&
      opclock.utc<l.cutoff_utc&&l.date==MDDateValue614((datetime)(opclock.utc/1000-10800));
  }
  if(l.order>0) {
   if(!pending_trail_started[k]||pending_trail[k].begin!=l.accepted_server){MDOpTrailInit(pending_trail[k],l.symbol,l.accepted_server,l.prices);pending_trail_started[k]=true;}
   f.pending_history[k]=MDOpTrailRead(pending_trail[k],opclock.server,why);
   f.pending_boundary[k]=pending_trail[k].boundary;
   if(!f.pending_history[k]&&why!="TRAIL_PREVIOUS_FAILURE")Report615("PENDING_HISTORY;key="+IntegerToString(l.key)+";"+why);
  }
 }
 if(!live)for(int k=0;k<operational.nlevels;k++)f.entry_ready[k]=false;
 for(int p=0;p<operational.npositions;p++) {
  MDOpPosition v=operational.positions[p];if(v.volume<=0)continue;MDOpLevel l=operational.levels[v.owner];
  if(!position_trail_started[p]){MDOpTrailInit(position_trail[p],l.symbol,v.first_server,l.prices);position_trail_started[p]=true;}
  f.position_history[p]=MDOpTrailRead(position_trail[p],opclock.server,why);f.position_boundary[p]=position_trail[p].boundary;
  if(!f.position_history[p])Report615("POSITION_HISTORY;identifier="+IntegerToString(v.identifier)+";"+why);
 }
}
void OperationalCycle() {
 if(fatal||!owns615)return;
 string why;bool clock=MDOpClockRead(opclock,operational.watermark,why);
 if(!clock)Report615("CLOCK;"+why);
 // Persist timer deadlines BEFORE potentially slow history calls.
 bool due=false;
 if(clock) {
  for(int i=0;i<operational.nlevels;i++)if(!operational.levels[i].cutoff&&opclock.utc>=operational.levels[i].cutoff_utc)due=true;
  for(int i=0;i<operational.npositions;i++)if(operational.positions[i].volume>0&&!operational.positions[i].closing&&
    MDProtectionCloseRequired(operational.positions[i].protection,opclock.utc,
      operational.positions[i].sl==operational.levels[operational.positions[i].owner].prices.sl_tick))due=true;
 }
 if(due){
  MDOpFrame timer;MDOpFrameReset(timer,opclock.utc,opclock.server,true,(bool)TerminalInfoInteger(TERMINAL_CONNECTED));
  MDOpState timed;
  if(!MDOpCycle(operational,inventory_b,timer,timed,why)||!Commit(timed,"TIMER_DEADLINE"))return;
 }
 // Daily data failure never bypasses inventory, protection or timer-based cutoff processing.
 Daily();if(fatal)return;
 bool stable=false;long began=(long)GetTickCount64();
 datetime start=(datetime)(opclock.server/1000-86400);
 for(int i=0;i<operational.nlevels;i++) {
  datetime day=(datetime)(MDCivilMidnight2026(operational.levels[i].date)/1000);
  if(day<start)start=day;
 }
 if(TerminalInfoInteger(TERMINAL_CONNECTED)) {
  stable=MDOpCollect(start,inventory_a,why)&&MDOpCollect(start,inventory_b,why)&&MDOpSameSnapshot(inventory_a,inventory_b)&&
   (long)GetTickCount64()-began<=3000&&Scope615()==operational.scope;
 }
 MDOpFrame frame;BuildFrame(frame,stable);
 if((long)GetTickCount64()-began>3000||Scope615()!=operational.scope||!TerminalInfoInteger(TERMINAL_CONNECTED))frame.stable=false;
 MDOpState next;
 if(!MDOpCycle(operational,inventory_b,frame,next,why)){Status("CYCLE_BLOCKED;"+why);return;}
 if(!Commit(next,"INTEGRATED_CYCLE"))return;
 int entries=0,protect=0,cancel=0,close=0,uncertain=0;
 for(int i=0;i<operational.nlevels;i++){
  if(operational.levels[i].entry.phase==1)entries++;
  if(operational.levels[i].cancellation.phase==1)cancel++;
  if(MDOpBusy(operational.levels[i].entry)||MDOpBusy(operational.levels[i].cancellation))uncertain++;
 }
 for(int i=0;i<operational.npositions;i++){
  if(operational.positions[i].protect.phase==1)protect++;
  if(operational.positions[i].close.phase==1)close++;
  if(MDOpBusy(operational.positions[i].protect)||MDOpBusy(operational.positions[i].close))uncertain++;
 }
 Status("INTEGRATED;"+why+";revision="+IntegerToString(operational.revision)+";entry_intents="+IntegerToString(entries)+
 ";SLTP_intents="+IntegerToString(protect)+";cancel_intents="+IntegerToString(cancel)+";close_intents="+IntegerToString(close)+
 ";unresolved="+IntegerToString(uncertain)+";transport=ABSENT;NATIVE_VALIDATION_PENDING");
}
int OnInit() {
 if(Instancia<1||Instancia>9999||VolumePorNivel<1||VolumePorNivel>1000000||IntervaloSegundos<1||IntervaloSegundos>30)return INIT_PARAMETERS_INCORRECT;
 if(_Symbol!="WIN$N"&&_Symbol!="WINZ26")return INIT_PARAMETERS_INCORRECT;
 string scope=Scope615();if(scope=="")return INIT_FAILED;
 lock615=FileOpen("ModeloD_OPERATIONAL_"+scope+".lock",FILE_READ|FILE_WRITE|FILE_BIN|FILE_COMMON);
 if(lock615==INVALID_HANDLE){Print("EXCLUSIVE_LOCK_FAILED");return INIT_FAILED;}
 string lock_marker="MDOP_LOCK_V1_"+scope;
 bool initialized=FileSize(lock615)>0;
 if(initialized&&FileReadString(lock615,(int)FileSize(lock615))!=lock_marker){Print("LOCK_MARKER_INVALID");return INIT_FAILED;}
 if(initialized&&!FileIsExist("ModeloD_OPERATIONAL_"+scope+".ledger",FILE_COMMON)&&!FileIsExist("ModeloD_OPERATIONAL_"+scope+".ledger.next",FILE_COMMON)){
  Print("PREVIOUS_LEDGER_MISSING_RESTORE_BACKUP_NEVER_REINITIALIZE");return INIT_FAILED;
 }
 owns615=true;MDOpInit(operational,scope,Instancia);MDOpClockInit(opclock);MDObserverStart615(obs615,scope);MDReset132(retry132);
 ledger_path="ModeloD_OPERATIONAL_"+scope+".ledger";string why;
 if(FileIsExist(ledger_path,FILE_COMMON)||FileIsExist(ledger_path+".next",FILE_COMMON)) {
  if(!MDOpRecoverFile(ledger_path,scope,Instancia,ledger,operational,why)){Print("LEDGER_BLOCKED;",why,";PRESERVE_FILES");return INIT_FAILED;}
 }
 report615=FileOpen("ModeloD_Integrado_"+scope+"_"+IntegerToString((long)TimeLocal())+"_"+IntegerToString((long)GetTickCount64())+".txt",
 FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON|FILE_SHARE_READ,0,CP_UTF8);
 if(report615==INVALID_HANDLE)return INIT_FAILED;
 if(ledger=="") {
  MDOpState seed=operational;
  if(!MDOpCommitFile(ledger_path,lock615,ledger,operational,seed,"CREATED",why)){Print("LEDGER_CREATE_FAILED;",why);return INIT_FAILED;}
 }
 if(!initialized){
  ResetLastError();uint marker_bytes=FileWriteString(lock615,lock_marker);FileFlush(lock615);
  if(marker_bytes!=(uint)StringLen(lock_marker)||GetLastError()!=0){Print("LOCK_MARKER_WRITE_FAILED");return INIT_FAILED;}
 }
 Report615("START;v=2.00;TRANSPORT_ABSENT;LEGACY_OBSERVATION_NOT_IMPORTED;revision="+IntegerToString(operational.revision));
 if(!EventSetTimer(IntervaloSegundos))return INIT_FAILED;
 return INIT_SUCCEEDED;
}
void OnTimer(){if(Scope615()!=operational.scope){fatal=true;Status("IDENTITY_CHANGED");return;}OperationalCycle();}
void OnTradeTransaction(const MqlTradeTransaction &trans,const MqlTradeRequest &request,const MqlTradeResult &result){transactions++;}
void OnChartEvent(const int id,const long &lparam,const double &dparam,const string &sparam) {
 if(id!=CHARTEVENT_CHART_CHANGE||!obs615.visible||!owns615)return;
 datetime begin=(datetime)(MDCivilMidnight2026(obs615.data.date)/1000+obs615.data.session.scheduled_open);
 datetime end=(datetime)(MDCivilMidnight2026(obs615.data.date)/1000+obs615.data.session.cutoff);
 MDVisualSync(0,(uint)Instancia,obs615.control.day,begin,end,true);
}
void OnDeinit(const int reason) {
 EventKillTimer();if(owns615){MDVisualClear(0,(uint)Instancia);Comment("");Report615("STOP;reason="+IntegerToString(reason)+";transport=ABSENT");}
 if(report615!=INVALID_HANDLE){FileClose(report615);report615=INVALID_HANDLE;}
 if(lock615!=INVALID_HANDLE){FileClose(lock615);lock615=INVALID_HANDLE;}owns615=false;
}
