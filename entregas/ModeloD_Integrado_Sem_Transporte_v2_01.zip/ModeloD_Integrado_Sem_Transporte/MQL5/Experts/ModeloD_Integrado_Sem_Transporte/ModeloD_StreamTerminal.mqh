#ifndef MD_STREAM_TERMINAL615
#define MD_STREAM_TERMINAL615
#include "ModeloD_SparseM1615N.mqh"
// Uma chamada consome no maximo cinco minutos FECHADOS, com auditoria M1.
// O estado original so muda depois que o bloco completo passa nas verificacoes.
bool MDStreamCollect615(MDStream615 &state,long end,string &reason,bool observation_only=false)
{
 long from=state.cursor;MDStream615 candidate=state;
 if(!MDStreamBegin615(candidate,from,end)){reason="JANELA_DE_BLOCO_INVALIDA";return false;}
 MqlTick ticks[];ResetLastError();
 int count=CopyTicksRange(state.data.contract,ticks,COPY_TICKS_TRADE,(ulong)from,(ulong)end);
 int error=GetLastError();
 if(count<0||error!=0){reason="COPY_TICKS_ERRO_"+IntegerToString(error)+";retornados="+IntegerToString(count);return false;}
 if(count>500000){reason="BLOCO_EXCEDE_CAPACIDADE_500000";return false;}
 for(int i=0;i<count;i++)
 {
  if(IsStopped()){reason="INTERROMPIDO";return false;}
  uint mask=TICK_FLAG_LAST|TICK_FLAG_VOLUME|TICK_FLAG_BUY|TICK_FLAG_SELL;
  if((ticks[i].flags&mask)==0||!MDStreamPush615(candidate,ticks[i].time_msc,ticks[i].last))
  {reason="TICK_OU_ABERTURA_INCONSISTENTE;indice="+IntegerToString(i)+
   ";msc="+IntegerToString(ticks[i].time_msc)+";last="+DoubleToString(ticks[i].last,16)+";flags="+IntegerToString((long)ticks[i].flags)+
   ";previous_accepted_msc="+IntegerToString(candidate.audit.last_msc)+";from="+IntegerToString(from)+";end="+IntegerToString(end)+
   ";expected_open_msc="+IntegerToString(candidate.data.open_msc)+";expected_open="+DoubleToString(candidate.data.values.open_today,16);return false;}
 }
 MqlRates rates[];ArraySetAsSeries(rates,false);ResetLastError();
 int bars=CopyRates(state.data.contract,PERIOD_M1,(datetime)(from/1000),(datetime)(end/1000),rates);
 error=GetLastError();int expected=(int)((end-from+1)/60000);
 if(error!=0||bars<0||bars>expected){reason="COBERTURA_M1_INVALIDA;erro="+IntegerToString(error)+";barras="+IntegerToString(bars);return false;}
 long previous=from-1;
 for(int i=0;i<bars;i++)
 {
  long stamp=(long)rates[i].time*1000;
  if(!MDSparseStamp615N(stamp,from,end,previous)){reason="M1_FORA_JANELA_DUPLICADO_OU_FORA_ORDEM";return false;}
  previous=stamp;
 }
 int r=0,empty=0;string absent="";
 for(int i=0;i<expected;i++)
 {
  long stamp=from+(long)i*60000;
  int k=(int)((stamp-candidate.audit.begin_msc)/60000);
  if(k<0||k>=540){reason="INDICE_MINUTO_INVALIDO";return false;}
  bool present=r<bars;
  if(present)present=(long)rates[r].time*1000==stamp;
  double o=0,h=0,l=0,c=0;
  if(present){o=rates[r].open;h=rates[r].high;l=rates[r].low;c=rates[r].close;}
  MDMinuteAudit m=candidate.audit.minutes[k];
  if(!MDSparseMinute615N(m,present?1:0,o,h,l,c,observation_only))
  {
   reason="TICKS_DIVERGEM_M1;minuto_msc="+IntegerToString(stamp)+
    ";bloco_inicio="+IntegerToString(from)+";bloco_fim="+IntegerToString(end)+
    ";ticks_minuto="+IntegerToString(m.count)+";barras_minuto="+IntegerToString(present?1:0)+
    ";ticks_O="+DoubleToString(m.o,8)+";ticks_H="+DoubleToString(m.h,8)+
    ";ticks_L="+DoubleToString(m.l,8)+";ticks_C="+DoubleToString(m.c,8)+
    ";M1_O="+DoubleToString(o,8)+";M1_H="+DoubleToString(h,8)+
    ";M1_L="+DoubleToString(l,8)+";M1_C="+DoubleToString(c,8);
   return false;
  }
  if(present)r++;
  else{empty++;absent+=IntegerToString(stamp)+",";}
 }
 if(!TerminalInfoInteger(TERMINAL_CONNECTED)){reason="DESCONECTADO_APOS_COLETA";return false;}
 if(!MDSparseFinish615N(candidate,observation_only)){reason="BLOCO_NAO_CONCLUIDO";return false;}
 state=candidate;reason="BLOCO_OBSERVADO;minutos_com_registros="+IntegerToString(bars)+";minutos_sem_registros="+IntegerToString(empty)+";ausentes_msc="+absent+";INTEGRIDADE_TOTAL_NAO_CERTIFICADA";return true;
}
#endif
