#ifndef MD_RETRY132
#define MD_RETRY132
// Somente observacao. Relogio monotono em milissegundos.
struct MDRetry132 { bool active; long from,end,started,next; int failures; };
void MDReset132(MDRetry132 &r){r.active=false;r.from=0;r.end=0;r.started=0;r.next=0;r.failures=0;}
bool MDExpired132(const MDRetry132 &r,long now){return r.active&&(now<r.started||now-r.started>=600000);}
bool MDDue132(const MDRetry132 &r,long now){return !r.active||(!MDExpired132(r,now)&&now>=r.next);}
bool MDFail132(MDRetry132 &r,long from,long end,long now)
{
 if(!r.active){r.active=true;r.from=from;r.end=end;r.started=now;r.failures=0;}
 if(r.from!=from||r.end!=end||MDExpired132(r,now))return false;
 r.failures++;r.next=now+30000;return true;
}
bool MDCanCommit132(const MDRetry132 &r,long from,long end,long now)
{return !r.active||(r.from==from&&r.end==end&&!MDExpired132(r,now));}
#endif
