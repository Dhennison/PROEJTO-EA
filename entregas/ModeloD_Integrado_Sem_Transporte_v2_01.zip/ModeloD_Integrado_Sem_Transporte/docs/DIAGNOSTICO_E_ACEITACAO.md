# Continuidade e diagnóstico

Base de origem: `ModeloD_Fluxo_Integrado_Sem_Ordens_v1_00`, anexada na transferência de 28/10/2026. O manifesto da entrega documental foi conferido: 1.850 arquivos, nenhuma divergência SHA-256. Foram inventariados 4.324 arquivos extraídos e examinadas as listagens de 67 ZIPs internos. Não foi localizada exportação integral de conversa; há histórico reconstruído que declara essa ausência. Não atribuí aprovação a mensagens inexistentes.

Foram consultados o TXT Onde paramos, documentação atualizada, histórico, resolução de 14/10, visual de 15/10, dois documentos V5, PDF ilustrado, módulos relevantes da pasta completa e relatórios originais recentes. Os relatórios confirmam a falha genérica em 09:25, posterior consulta válida e reexecução sem alteração de código. Isso não prova a causa inicial nem recuperação automática.

A resolução mantém fórmulas e cinco níveis independentes, primeiro toque Last, limites fixos normalizados, uma oportunidade por sessão, conta HEDGE e corte. A atualização visual mostra auxiliares em esquemas; o histórico registra o pedido posterior específico de sete linhas, já atendido pela base. A apresentação herdada de sete linhas foi mantida; não foram reintroduzidas linhas auxiliares no gráfico. Cálculo interno permanece completo. Não foi identificada divergência matemática que exigisse nova decisão de estratégia.

# O que foi implementado

| Lacuna anterior | Ligação entregue |
| --- | --- |
| Preview com intenção hipoteticamente durável | Intenções e tentativas são campos distintos do diário operacional; intenção suprimida não incrementa tentativas |
| Q/P exclusivos de teste | Novo núcleo sem dependência desses armazenadores; módulos de teste permanecem na regressão |
| Q/L7 e estados separados | Uma revisão contém níveis, recibos, posições, consumo, ações, respostas e agendas; gravada e relida em conjunto |
| B1 limitado a uma posição | Um controlador por identificador estável, com posições simultâneas nas cinco cadeias |
| Mudança de ticket bloqueada na bancada | Ticket atual reconciliado por POSITION_IDENTIFIER; tentativa incerta no ticket anterior preservada até efeito comprovado |
| Fechamento/desaparecimento | Saldo de deals de entrada/saída confrontado com cada posição; desaparecimento sem saída comprovada não confirma fechamento |
| Execução parcial | Saldo da ordem original preservado; volume preenchido recebe intenção de SL/TP; fechamento parcial confirmado agenda só o residual |
| Intenção tratada como execução | Fases separadas: ausente, intenção, tentativa incerta, resposta aguardando conciliação, rejeição transitória/definitiva, efeito verificado e intenção superada |
| Relógio BENCH/SAME_CLOCK | Produtor terminal com âncora recente TimeCurrent, UTC/servidor/monotônico e deadlines absolutos persistidos; testes em dois processos distintos |
| Histórico operacional desconhecido | Leituras de ordens, deals com preço executado e SL/TP reais; dois inventários iguais; reconstrução temporal por origem/fill, com ambiguidades preservadas |
| Gestão dependente da coleta diária | Timer processa deadlines antes de chamadas históricas; falha diária não impede inventário e gestão de posições já vinculadas |
| EA observacional temporário | EA principal único, sem duração máxima automática, com diário e log próprios |

`ModeloD_Operational.mqh` concentra transições e conciliação, reutilizando Core, Chain, Protection, Recovery e identidade da base. `OperationalCodec` serializa e verifica cada revisão encadeada, incluindo monotonicidade de consumo/identidades/agendas. `OperationalFile` escreve uma versão completa em `.next`, confere bytes, publica e relê. O guard estático do lock detecta diário desaparecido; não é uma segunda transação de gestão. `OperationalTerminal` produz inventário, SL/TP, preços de deals, relógio e janelas Last. O EA coordena esses produtores e grava o candidato inteiro antes de considerar um estado durável.

Recebimentos de deals ficam preservados com ticket, ordem, identificador, Magic, tempo, tipo, lado, volume e preço executado. Mudança de um recibo anteriormente conhecido é bloqueada, mesmo quando os totais continuam iguais. Admissão de origem exige tentativa persistente e recibo inequívoco por ticket da resposta ou comentário único da tentativa, além das propriedades da ordem. Origem ambígua ou comentário ausente/modificado não é substituído por uma suposição baseada em Magic.

Não existe `OrderSend`, `OrderSendAsync`, CTrade, cancelamento, alteração ou fechamento comercial neste fluxo. `MDOpBegin` e `MDOpResponse` são transições candidatas exercitadas pelos testes; o EA não inventa chamadas a elas quando o transporte está ausente. Consequentemente a observação natural de uma conta vazia deve continuar mostrando zero tentativas e zero operações reais. A implementação do transporte é trabalho posterior, em ambiente de teste autorizado, com validação de recibos e permissão efêmera após commit; não basta mudar uma flag.

# Evidências e limites de aceitação

`python3 tests/run_local.py` executa a regressão herdada, transições integradas, falhas de armazenamento, reinício em processos separados e adaptação C++ das funções do EA com APIs MT5 simuladas. A opção `--sanitize` instrumenta C++ com AddressSanitizer/UndefinedBehaviorSanitizer. Os logs completos ficam em VALIDACAO_LOCAL.txt e VALIDACAO_SANITIZERS.txt. Esses testes podem encontrar erros de lógica e armazenamento local; não validam bibliotecas/API/semântica nativa do MT5 nem o servidor Genial.

A compilação e os 631 checks nativos anteriores foram informados para a v1.00. Nenhuma evidência nativa foi transferida automaticamente para esta v2.00. O teste MQL5 consolidado reutiliza a bateria de 631 e executa os novos casos de domínio/arquivos; o mock de APIs e a injeção de falhas de arquivo pertencem ao harness C++, não são apresentados como testes nativos.

Cobertura nova inclui: cinco entradas no mesmo ciclo, cinco cadeias simultâneas buy/sell, múltiplas posições da mesma cadeia, execução parcial, tentativa incerta, rejeições, toque antes de aceite/retry, cancelamento com fill concorrente, troca de ticket, proteção confirmada por propriedades, seis conclusões + janela adicional, TP ausente com SL presente, fechamento parcial, saída manual vinculada, corte desconectado, estado corrompido, gravador desatualizado e retomada de publicação interrompida. Sem preenchimento de uma conta real, não há evidência de gestão operacional ou transporte real.

Pendências de aceitação do Item 1: compilar EA e script no MetaEditor, executar a bateria consolidada no MT5, inspecionar relatórios nativos e tratar incompatibilidades encontradas. Também permanecem as validações de servidor/relógio/calendário/abertura/histórico declaradas pela base. Não classifico o Item 1 como operacionalmente validado apenas pela implementação local. Os limites de capacidade, fuso, dados e retentativas constam no LEIA_PRIMEIRO.

Itens 2–4 não foram executados: transporte restrito ao Tester autorizado, histórico real com contratos/ajustes corretos, comparação operação por operação com Work e testes em conta demonstrativa. Não há .ex5 produzido nem habilitação de negociação real.
