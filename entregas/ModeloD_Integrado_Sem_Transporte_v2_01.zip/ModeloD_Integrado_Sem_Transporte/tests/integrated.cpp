#define main baseline_main
#include "host.cpp"
#undef main
#include "../MQL5/Scripts/ModeloD_Integrado_Sem_Transporte/ModeloD_OperationalCases.mqh"
int main(){std::filesystem::remove_all("/tmp/md615k_host");std::filesystem::create_directories("/tmp/md615k_host");RunOperationalCases();return op_failures?1:0;}
