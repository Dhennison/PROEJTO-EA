#define main baseline_main
#include "host.cpp"
#undef main
bool fail_write=false,fail_flush=false,fail_move=false,fail_read_after_move=false,fail_next_read=false;
uint FaultWrite(int h,string s,int n=-1){if(fail_write){fail_write=false;lastError=8;return FileWriteString(h,s,3);}return FileWriteString(h,s,n);}
void FaultFlush(int h){FileFlush(h);if(fail_flush){lastError=8;fail_flush=false;}}
bool FaultMove(string a,int common,string b,int flags){if(fail_move){fail_move=false;return false;}bool result=FileMove(a,common,b,flags);if(result&&fail_read_after_move){fail_read_after_move=false;fail_next_read=true;}return result;}
string FaultRead(int h,int n){if(fail_next_read){fail_next_read=false;return "";}return FileReadString(h,n);}
#define FileWriteString FaultWrite
#define FileFlush FaultFlush
#define FileMove FaultMove
#define FileReadString FaultRead
#include "../MQL5/Scripts/ModeloD_Integrado_Sem_Transporte/ModeloD_OperationalCases.mqh"
int main(){
 std::filesystem::remove_all("/tmp/md615k_host");std::filesystem::create_directories("/tmp/md615k_host");
 MDOpState fixture,state,candidate,reopened;MDOpSnapshot book;MDOpFrame f;OPFilled(fixture,book,f);
 MDOpInit(state,fixture.scope,1);string ledger="",why,path="FAULTS.ledger",disk;
 int lock=FileOpen(path+".lock",FILE_READ|FILE_WRITE|FILE_BIN|FILE_COMMON);
 OPCheck(MDOpCommitFile(path,lock,ledger,state,fixture,"SEED",why),"fault fixture initial commit");
 candidate=state;MDOpBegin(candidate,0,0,2,200000,true,true);long revision=state.revision;
 fail_write=true;
 OPCheck(!MDOpCommitFile(path,lock,ledger,state,candidate,"PREPARE",why)&&state.revision==revision&&state.positions[0].protect.serial==0,
 "partial write cannot authorize a transport or mutate committed attempt counter");
 OPCheck(MDOpRecoverFile(path,state.scope,1,disk,reopened,why)&&reopened.positions[0].protect.serial==0,"reopen after partial candidate write retains prior integrated state");
 fail_flush=true;
 OPCheck(!MDOpCommitFile(path,lock,ledger,state,candidate,"PREPARE",why),"flush error is not reported as durable commit");
 OPCheck(MDOpRecoverFile(path,state.scope,1,disk,reopened,why)&&reopened.positions[0].protect.phase==2,
 "complete staging file after uncertain flush is recovered conservatively as uncertain attempt");
 ledger=disk;state=reopened;candidate=state;
 MDOpResponse(candidate,0,0,2,1,200100,true,10016,0,0);
 fail_move=true;
 OPCheck(!MDOpCommitFile(path,lock,ledger,state,candidate,"RESPONSE",why)&&state.positions[0].protect.phase==2,
 "publication error cannot pretend response has committed");
 OPCheck(MDOpRecoverFile(path,state.scope,1,disk,reopened,why)&&reopened.positions[0].protect.phase==4,
 "crash between write and publication recovers response and protection schedule together");
 ledger=disk;state=reopened;candidate=state;candidate.watermark=202000;candidate.levels[0].cancel=true;
 fail_read_after_move=true;
 OPCheck(!MDOpCommitFile(path,lock,ledger,state,candidate,"CANCEL",why),"readback failure cannot grant durability to caller");
 OPCheck(MDOpRecoverFile(path,state.scope,1,disk,reopened,why)&&reopened.levels[0].cancel,
 "restart sees committed cancellation despite caller readback failure");
 OPCheck(!MDOpBegin(reopened,0,0,2,203000,true,true),"restart does not recreate a transport permit");
 FileClose(lock);Print("FAULT_INJECTION;Checks=",op_checks,";Failures=",op_failures);return op_failures?1:0;
}
