#define main baseline_main
#include "host.cpp"
#undef main
#include "../MQL5/Experts/ModeloD_Integrado_Sem_Transporte/ModeloD_OperationalCases.mqh"
int main(int argc,char **argv){
 if(argc!=2)return 2;
 string mode=argv[1],path="PROCESS_RESTART.ledger",text,why;MDOpState state;
 if(mode=="write"){
  std::filesystem::remove_all("/tmp/md615k_host");std::filesystem::create_directories("/tmp/md615k_host");
  MDOpSnapshot b;MDOpFrame f;OPFilled(state,b,f);
  for(int i=0;i<6;i++){long now=200000+i*2000;f.utc=now;b.server_msc=now;OPCycle(state,b,f);
   if(!MDOpBegin(state,0,0,2,now,true,true)||!MDOpResponse(state,0,0,2,i+1,now+100,true,10016,0,0))return 3;}
  int h=FileOpen(path+".lock",FILE_READ|FILE_WRITE|FILE_BIN|FILE_COMMON);MDOpState empty;MDOpInit(empty,state.scope,1);
  bool saved=MDOpCommitFile(path,h,text,empty,state,"SIX_ATTEMPTS",why);FileClose(h);
  if(!saved)return 4;
  Print("PROCESS_WRITE;SIX_COMPLETED;UTC_DEADLINE_RETAINED");return 0;
 }
 if(mode=="resume"){
  if(!MDOpRecoverFile(path,MDContext612(1,"TEST",1),1,text,state,why))return 5;
  MDOpFrame f;MDOpFrameReset(f,state.positions[0].protection.sixth_completed_ms+180000,500000,true,false);
  MDOpSnapshot missing;MDOpState next;
  if(!MDOpCycle(state,missing,f,next,why)||!next.positions[0].closing||next.positions[0].close.phase!=1||
    next.positions[0].protection.initial_completed!=6||next.positions[0].protect.serial!=6||next.positions[1].closing)return 6;
  Print("PROCESS_RESUME;DEADLINE_AFTER_OFFLINE=OK;NO_DUPLICATE=OK;SECOND_POSITION_INDEPENDENT=OK");return 0;
 }
 return 7;
}
