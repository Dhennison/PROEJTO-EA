// C++ adaptation with simulated MT5 APIs; NOT an MQL5 compiler or terminal.
#define main baseline_main
#include "host.cpp"
#undef main
#include <vector>
#include <ctime>
#include "../MQL5/Experts/ModeloD_Integrado_Sem_Transporte/ModeloD_OperationalCases.mqh"
#include "../MQL5/Experts/ModeloD_Integrado_Sem_Transporte/ModeloD_Observer.mqh"
#include "../MQL5/Experts/ModeloD_Integrado_Sem_Transporte/ModeloD_Stream.mqh"
#define MD_TERMINAL69
#define MD_DAILY_TERMINAL614
#define MD_STREAM_TERMINAL615
#define MODELOD_CHART_MQH
using datetime=long;
struct MqlDateTime{int year,mon,day;};
struct MqlTick{long time_msc;double last;uint flags;};
struct MqlRates{long time;double open,high,low,close;};
struct MqlTradeTransaction{};struct MqlTradeRequest{};struct MqlTradeResult{};
const int TERMINAL_CONNECTED=1,ACCOUNT_LOGIN=2,ACCOUNT_SERVER=3,ACCOUNT_MARGIN_FREE=4,
 TIME_DATE=1,TIME_SECONDS=2,FILE_SHARE_READ=128,
 TICK_FLAG_LAST=8,TICK_FLAG_VOLUME=16,TICK_FLAG_BUY=32,TICK_FLAG_SELL=64,
 COPY_TICKS_TRADE=0,PERIOD_M1=1,ORDER_TYPE_BUY=0,ORDER_TYPE_SELL=1,
 SYMBOL_TRADE_TICK_SIZE=11,SYMBOL_VOLUME_MIN=12,SYMBOL_VOLUME_MAX=13,SYMBOL_VOLUME_STEP=14,
 SYMBOL_TRADE_MODE=15,SYMBOL_ORDER_MODE=16,SYMBOL_TRADE_STOPS_LEVEL=17,SYMBOL_TRADE_FREEZE_LEVEL=18,
 SYMBOL_POINT=19,SYMBOL_ASK=20,SYMBOL_BID=21,SYMBOL_ORDER_LIMIT=2,SYMBOL_ORDER_SL=4,SYMBOL_ORDER_TP=8,
 SYMBOL_TRADE_MODE_FULL=4,SYMBOL_TRADE_MODE_LONGONLY=1,SYMBOL_TRADE_MODE_SHORTONLY=2,
 ORDER_PRICE_OPEN=10,ORDER_SL=11,ORDER_TP=12,ORDER_POSITION_ID=13,ORDER_COMMENT=14,POSITION_SL=15,POSITION_TP=16,
 DEAL_PRICE=20,CHARTEVENT_CHART_CHANGE=1,INIT_PARAMETERS_INCORRECT=2,INIT_FAILED=1,INIT_SUCCEEDED=0;
long mock_utc=11000000,mock_mono=10000;bool mock_broker_fresh=true;bool mock_connected=true,mock_unstable=false,mock_price_error=false,mock_tick_error=false;
int mock_calls=0;long selected_order=0,selected_pos=0;string _Symbol="WIN$N";
MDOpSnapshot mock_book;std::vector<MqlTick> mock_ticks;
long TimeGMT(){return mock_utc/1000;}
long TimeTradeServer(){return (mock_utc-10800000)/1000;}
long TimeCurrent(){return mock_broker_fresh?TimeTradeServer():0;}
unsigned long GetTickCount64(){return mock_mono;}
long AccountInfoInteger(int){return 1;}string AccountInfoString(int){return "TEST";}
double AccountInfoDouble(int){return 100000000;}
bool TerminalInfoInteger(int){return mock_connected;}
bool TimeToStruct(long stamp,MqlDateTime &out){std::time_t value=stamp;auto g=std::gmtime(&value);out.year=g->tm_year+1900;out.mon=g->tm_mon+1;out.day=g->tm_mday;return true;}
int MDDateValue614(long stamp){MqlDateTime v;TimeToStruct(stamp,v);return v.year*10000+v.mon*100+v.day;}
string TimeToString(long v,int){return IntegerToString(v);}
bool EventSetTimer(int){return true;}void EventKillTimer(){}bool IsStopped(){return false;}
template<class...T>void Comment(T...){ }
void MDVisualClear(long,uint){}
bool MDVisualSync(long,uint,const MDDay &,datetime,datetime,bool){return true;}
bool MDCollectDaily614(int,MDDailyRaw614 &,string &why){why="SIMULATED_DAILY_DATA_FAILURE";return false;}
bool MDStreamCollect615(MDStream615 &,long,string &,bool){return false;}
bool SymbolInfoDouble(string,int prop,double &v){
 if(prop==SYMBOL_TRADE_TICK_SIZE)v=5;
 else if(prop==SYMBOL_VOLUME_MAX)v=100000;
 else if(prop==SYMBOL_ASK)v=210000;
 else if(prop==SYMBOL_BID)v=209995;
 else v=1;
 return true;
}
bool SymbolInfoInteger(string,int prop,long &v){if(prop==SYMBOL_TRADE_MODE)v=SYMBOL_TRADE_MODE_FULL;else if(prop==SYMBOL_ORDER_MODE)v=14;else v=0;return true;}
bool SymbolInfoTick(string,MqlTick &v){if(mock_ticks.empty())return false;v=mock_ticks.back();return true;}
bool OrderCalcMargin(int,string,double,double,double &v){v=100;return true;}
bool Collect69(datetime,datetime,MDSnapshot69 &s,string &why){
 s=mock_book.book;mock_calls++;
 if(mock_unstable&&mock_calls%2==0)s.o[0].order.remaining-=1;
 why="MOCK_INVENTORY";return mock_connected;
}
bool OrderSelect(ulong id){selected_order=(long)id;return true;}
bool PositionSelectByTicket(ulong id){selected_pos=(long)id;return true;}
int order_index(long id){for(int i=0;i<mock_book.book.orders;i++)if(mock_book.book.o[i].order.ticket==id)return i;return -1;}
int pos_index(long id){for(int i=0;i<mock_book.book.positions;i++)if(mock_book.book.p[i].ticket==id)return i;return -1;}
bool OD69(int prop,double &v){int i=order_index(selected_order);if(i<0)return false;auto x=mock_book.orders[i];v=prop==ORDER_PRICE_OPEN?x.price:(prop==ORDER_SL?x.sl:x.tp);return true;}
bool OI69(int,long &v){int i=order_index(selected_order);if(i<0)return false;v=mock_book.orders[i].position_id;return true;}
bool OS69(int,string &v){int i=order_index(selected_order);if(i<0)return false;v=mock_book.orders[i].comment;return true;}
bool HD69(ulong id,int prop,double &v){selected_order=id;return OD69(prop,v);}
bool HI69(ulong id,int prop,long &v){selected_order=id;return OI69(prop,v);}
bool HS69(ulong id,int prop,string &v){selected_order=id;return OS69(prop,v);}
bool DD69(ulong id,int,double &v){for(int i=0;i<mock_book.book.deals;i++)if(mock_book.book.d[i].ticket==(long)id){v=mock_book.deal_price[i];return !mock_price_error;}return false;}
bool PD69(int prop,double &v){int i=pos_index(selected_pos);if(i<0)return false;v=prop==POSITION_SL?mock_book.sl[i]:mock_book.tp[i];return true;}
int CopyTicksRange(string,std::vector<MqlTick> &out,int,ulong from,ulong until){
 out.clear();if(mock_tick_error){lastError=1;return -1;}
 for(auto v:mock_ticks)if(v.time_msc>=(long)from&&v.time_msc<=(long)until)out.push_back(v);
 return out.size();
}
int CopyRates(string,int,datetime,std::time_t,std::vector<MqlRates> &out){out.clear();return 0;}
#include "EA_ADAPTED_PATH"
void advance(long delta){mock_utc+=delta;mock_mono+=delta;}
int main(){
 std::filesystem::remove_all("/tmp/md615k_host");std::filesystem::create_directories("/tmp/md615k_host");
 MDOpState seed;MDOpFrame f;OPFilled(seed,mock_book,f);
 for(int i=0;i<seed.nlevels;i++)seed.levels[i].cutoff_utc=12000000;
 string scope=seed.scope,path="ModeloD_OPERATIONAL_"+scope+".ledger",text,why;
 int h=FileOpen("ModeloD_OPERATIONAL_"+scope+".lock",FILE_READ|FILE_WRITE|FILE_BIN|FILE_COMMON);
 MDOpState empty;MDOpInit(empty,scope,1);OPCheck(MDOpCommitFile(path,h,text,empty,seed,"RUNTIME_SEED",why),"seed integrated ledger with proven synthetic positions");FileClose(h);
 OPCheck(OnInit()==INIT_SUCCEEDED,"actual EA OnInit reopens integrated ledger");
 OnTimer();advance(2000);OnTimer();advance(2000);OnTimer();
 OPCheck(operational.npositions==2&&!fatal,"actual EA timer keeps both positions despite daily-data failure");
 OPCheck(opclock.ok&&opclock.offset==-10800,"runtime clock samples measured server timezone");
 OPCheck(operational.positions[0].protect.phase==1&&operational.positions[1].protect.phase==1,"actual timer persists missing SLTP intents");
 long revision=operational.revision;mock_unstable=true;advance(2000);OnTimer();
 OPCheck(operational.revision==revision,"unstable pair of real collector calls cannot commit reconciliation");mock_unstable=false;
 mock_price_error=true;MDOpSnapshot rejected;
 OPCheck(!MDOpCollect(0,rejected,why)&&why=="DEAL_PRICE_READ_FAILED","terminal producer rejects unavailable execution price");mock_price_error=false;
 mock_book.sl[0]=operational.levels[0].prices.sl_tick;mock_book.tp[0]=operational.levels[0].prices.tp_tick;
 advance(2000);OnTimer();
 OPCheck(operational.positions[0].sl==mock_book.sl[0]&&operational.positions[0].tp==mock_book.tp[0],"live SLTP properties feed the persisted integrated state");
 mock_book.book.p[0].ticket=999;advance(2000);OnTimer();
 OPCheck(operational.positions[0].ticket==999&&operational.positions[0].identifier==700,"actual EA reconciles migrated ticket without resetting identifier");
 mock_connected=false;advance(12000000-mock_utc);OnTimer();
 OPCheck(operational.levels[0].cutoff&&operational.positions[0].close.phase==1&&operational.positions[1].close.phase==1,"actual timer cutoff works without quote, daily data or connection");
 OPCheck(operational.positions[0].close.serial==0,"actual EA does not transport shutdown intentions");
 OnDeinit(1);fatal=false;report_error=false;stream_started615=false;mock_connected=true;mock_calls=0;
 for(int i=0;i<MDOP_LEVELS;i++)pending_trail_started[i]=false;
 for(int i=0;i<MDOP_POSITIONS;i++)position_trail_started[i]=false;
 OPCheck(OnInit()==INIT_SUCCEEDED&&operational.levels[0].cutoff&&operational.positions[0].close.phase==1,"EA reinitialization retains cutoff and untransported intentions");
 OnDeinit(1);
 // Exercise the actual new trail producer using API mocks, including timestamp ambiguity.
 MDOpTrail trail;MDLevel price=seed.levels[0].prices;
 mock_ticks={{160000,price.sl,8},{160001,price.entry,8},{160002,price.tp+5,8}};
 MDOpTrailInit(trail,"WINZ26",160000,price);
 OPCheck(!MDOpTrailRead(trail,160010,why)&&trail.ambiguous&&trail.boundary,"same-ms stop remains ambiguous; later target is proven post-origin");
 mock_ticks={{160000,price.sl,8}};MDOpTrailInit(trail,"WINZ26",160000,price);
 OPCheck(!MDOpTrailRead(trail,160010,why)&&!trail.boundary,"pre/same-fill boundary is not converted into post-fill close evidence");
 mock_ticks={{160001,price.entry,8},{160002,price.sl-10,8}};MDOpTrailInit(trail,"WINZ26",160000,price);
 OPCheck(MDOpTrailRead(trail,160010,why)&&trail.boundary,"post-origin gap beyond mathematical stop creates boundary evidence");
 mock_tick_error=true;MDOpTrailInit(trail,"WINZ26",160000,price);
 OPCheck(!MDOpTrailRead(trail,160010,why)&&trail.cursor==160001,"failed tick query leaves trail cursor unchanged");mock_tick_error=false;
 MDOpClock c;MDOpClockInit(c);MDOpClockRead(c,0,why);advance(2000);MDOpClockRead(c,0,why);advance(2000);
 OPCheck(MDOpClockRead(c,0,why),"continuous clock established by successive samples");mock_utc+=10000;
 OPCheck(!MDOpClockRead(c,0,why)&&why=="WALL_CLOCK_DISCONTINUITY","wall-clock jump without monotonic progress is refused");
 MDOpClock unanchored;MDOpClockInit(unanchored);mock_broker_fresh=false;
 for(int i=0;i<3;i++){advance(2000);MDOpClockRead(unanchored,0,why);}
 OPCheck(!unanchored.ok&&why=="FRESH_BROKER_TIME_REQUIRED_AFTER_RESTART","startup cannot certify time from two estimates sharing the same PC clock");mock_broker_fresh=true;
 Print("RUNTIME_MOCK;Checks=",op_checks,";Failures=",op_failures,";API_MT5_SIMULADA;NAO_E_COMPILACAO_MQL5");return op_failures?1:0;
}
