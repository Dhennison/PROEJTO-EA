Validação nativa recebida do usuário em 28/10/2026, referente ao pacote v2.01.

Script Test_Integrado_Sem_Transporte.mq5: MetaEditor gerou código com 0 erros e 0 avisos, 10382 ms, alvo AVX2 + FMA3 (saída fornecida pelo usuário).

MT5, WIN$N M5, 2026.10.28 22:12:41: regressão 631 verificações / 0 falhas; operacional integrado 104 verificações / 0 falhas. Eventos sintéticos, arquivos reais, sem transporte. Relatório original anexo conferido: 740 linhas e nenhuma linha FAIL.

Relatório: ModeloD_Validacao_Integrada_1793225561_204119.txt
SHA256: e4d5e4e3f49bb3f3cd0671fa38a82997240f19b8ca538d346fbd43dbea4b941f

Esta evidência confirma a compilação e execução NATIVAS do script e seus módulos exercitados. Compilação do EA principal desta entrega, execução observacional do EA, produtores reais de mercado/relógio e transporte permanecem sem confirmação. Não certifica gestão de ordens/posições reais nem conclui a aceitação operacional do Item 1.

Atualização posterior recebida: EA principal compilado nativamente com 0 erros e 1 aviso de sombreamento, código gerado em 4921 ms, AVX2 + FMA3. A execução observacional do EA permanece pendente. O pacote v2.02 corrige o nome do parâmetro; a recompilação dessa correção permanece pendente.
