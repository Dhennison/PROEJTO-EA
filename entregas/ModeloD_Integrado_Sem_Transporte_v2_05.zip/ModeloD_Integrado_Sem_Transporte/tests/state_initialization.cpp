#define main baseline_main
#include "host.cpp"
#undef main
#include "../MQL5/Scripts/ModeloD_Integrado_Sem_Transporte/ModeloD_OperationalCases.mqh"
int main(){
 MDOpState original,decoded;MDOpSnapshot book;MDOpFrame frame;OPFilled(original,book,frame);
 string encoded=MDOpEncode(original);
 MDOpInit(decoded,original.scope,original.instance);
 decoded.levels[MDOP_LEVELS-1].consumed=true;
 decoded.positions[MDOP_POSITIONS-1].closing=true;
 if(!MDOpDecode(encoded,original.scope,original.instance,decoded))return 1;
 if(decoded.levels[MDOP_LEVELS-1].consumed||decoded.positions[MDOP_POSITIONS-1].closing)return 2;
 if(MDOpEncode(decoded)!=encoded)return 3;
 for(int i=decoded.nlevels;i<MDOP_LEVELS;i++){
  MDOpLevel copied=decoded.levels[i];
  if(copied.consumed||copied.cancel||copied.closing||copied.cutoff||copied.conflict||copied.prices.buy||copied.prices.valid_open||copied.prices.geometry_blocked)return 4;
 }
 for(int i=decoded.npositions;i<MDOP_POSITIONS;i++){
  MDOpPosition copied=decoded.positions[i];
  if(copied.closing||copied.protection.inflight||copied.protection.started)return 5;
 }
 Print("STATE_INITIALIZATION;INACTIVE_SLOTS=INITIALIZED;ACTIVE_STATE=UNCHANGED;FORMAT_MDOP1=UNCHANGED");return 0;
}
