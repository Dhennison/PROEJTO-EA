#!/usr/bin/env python3
"""Local C++/mock checks. This script never claims native MQL5 compilation."""
import argparse
import os
from pathlib import Path
import re
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[1]
EXPERT = ROOT / 'MQL5/Experts/ModeloD_Integrado_Sem_Transporte'
parser = argparse.ArgumentParser()
parser.add_argument('--sanitize', action='store_true')
parser.add_argument('--only-runtime', action='store_true')
parser.add_argument('--report', type=Path, default=ROOT / 'docs/VALIDACAO_LOCAL.txt')
args = parser.parse_args()
execution_env = os.environ.copy()
if args.sanitize:
    execution_env['UBSAN_OPTIONS'] = execution_env.get('UBSAN_OPTIONS', '') + ':halt_on_error=1:print_stacktrace=1'
    execution_env['ASAN_OPTIONS'] = execution_env.get('ASAN_OPTIONS', '') + ':halt_on_error=1'
report = ['VALIDACAO LOCAL C++ E APIs MT5 SIMULADAS. NAO E COMPILACAO MQL5.\n']

def run(command):
    report.append('\n$ ' + ' '.join(map(str, command)) + '\n')
    result = subprocess.run(command, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, env=execution_env)
    report.append(result.stdout)
    report.append(f'EXIT_STATUS={result.returncode}\n')
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(''.join(report), encoding='utf-8')
    if result.returncode:
        print(result.stdout[-8000:])
        raise SystemExit(result.returncode)
    return result.stdout

with tempfile.TemporaryDirectory(prefix='modelod_validation_') as temporary:
    build = Path(temporary)
    flags = ['-std=c++17', '-g', '-Wall', '-Wextra', '-Wno-unused-parameter']
    flags += ['-O0' if args.only_runtime else '-O1', '-fsanitize=address,undefined', '-fno-omit-frame-pointer'] if args.sanitize else ['-O1']
    # The inherited host uses a dedicated /tmp fixture directory; tests run sequentially.
    for name in ([] if args.only_runtime else ['host', 'integrated', 'faults', 'restart_process', 'regression_repeat', 'state_initialization']):
        run(['c++', *flags, f'tests/{name}.cpp', '-o', str(build / name)])
    for name in ([] if args.only_runtime else ['host', 'integrated', 'faults', 'regression_repeat', 'state_initialization']):
        output = run([str(build / name)])
        for line in output.splitlines():
            if line.startswith(('TESTE_', 'FAULT_INJECTION', 'REPEATED_REGRESSION', 'STATE_INITIALIZATION')):
                print(line)
    if not args.only_runtime:
        print(run([str(build / 'restart_process'), 'write']).strip())
        print(run([str(build / 'restart_process'), 'resume']).strip())
    # Adapt only C++ syntax for dynamic arrays, input and #property.
    # All trading APIs below remain simulated; use MetaEditor for native compilation.
    adapted = build / 'adapted'
    adapted.mkdir()
    for file in EXPERT.iterdir():
        if file.suffix not in ('.mqh', '.mq5'):
            continue
        content = re.sub(r'^#property.*$', '', file.read_text(), flags=re.M)
        content = re.sub(r'^input ', '', content, flags=re.M)
        content = re.sub(r'\b(MqlTick|MqlRates) (\w+)\[\];', r'std::vector<\1> \2;', content)
        (adapted / file.name).write_text(content)
    mock = (ROOT / 'tests/runtime_mock.cpp').read_text()
    mock = mock.replace('EA_ADAPTED_PATH', str(adapted / 'EA_ModeloD_Fluxo_Sem_Ordens.mq5'))
    mock = mock.replace('#include "host.cpp"', f'#include "{ROOT}/tests/host.cpp"')
    mock = mock.replace('#include "../MQL5/', f'#include "{ROOT}/MQL5/')
    (adapted / 'runtime_mock.cpp').write_text(mock)
    run(['c++', *flags, str(adapted / 'runtime_mock.cpp'), '-o', str(build / 'runtime_mock')])
    output = run([str(build / 'runtime_mock')])
    print(output.splitlines()[-1])
print(f'Relatorio: {args.report}')
