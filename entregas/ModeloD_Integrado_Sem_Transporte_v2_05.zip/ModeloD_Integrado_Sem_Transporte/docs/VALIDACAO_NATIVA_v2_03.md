Confirmação nativa recebida do usuário — 28/10/2026.

Script v2.03 compilado no MetaEditor: 0 erros, 0 avisos, 10846 ms, AVX2 + FMA3 (saída fornecida).

Duas execuções consecutivas no MT5 WIN$N M5, às 22:44:49 e 22:46:10, produziram identificadores de execução distintos. Os dois TXT foram lidos integralmente: cada um possui 631 checks de regressão, zero falhas, e 104 checks operacionais, zero falhas; 735 linhas PASS e nenhuma FAIL. Validação nativa da repetição da bateria com o isolamento corrigido confirmada nesse cenário. Eventos sintéticos, arquivos reais, transporte ausente.

Não extrapolar para validação de gestão operacional com dados/posições reais. A compilação do EA corrigido v2.02 sem o aviso de sombreamento ainda aguarda confirmação. O EA não mudou no pacote v2.03. Execução observacional do EA e produtores de mercado continuam pendentes; Strategy Tester, Work e conta demonstrativa não foram executados.

Relatórios originais preservados:

ModeloD_Validacao_Integrada_MQL5_REGRESSION_1793227489_1437_0.txt
SHA256: e4d5e4e3f49bb3f3cd0671fa38a82997240f19b8ca538d346fbd43dbea4b941f

ModeloD_Validacao_Integrada_MQL5_REGRESSION_1793227570_1401_0.txt
SHA256: e4d5e4e3f49bb3f3cd0671fa38a82997240f19b8ca538d346fbd43dbea4b941f

Confirmação posterior do usuário: EA_ModeloD_Fluxo_Sem_Ordens.mq5 compilado com 0 erros e 0 avisos, código gerado em 4786 ms, AVX2 + FMA3. Remoção do aviso de sombreamento confirmada nativamente. Execução observacional do EA segue pendente para a sessão aberta de 29/10/2026.
