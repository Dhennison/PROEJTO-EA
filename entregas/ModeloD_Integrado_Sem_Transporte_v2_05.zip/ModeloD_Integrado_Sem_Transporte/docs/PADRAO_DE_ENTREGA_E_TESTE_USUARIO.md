Padrão solicitado pelo usuário em 28/10/2026.

Gráfico de referência para instalação e testes: WIN$N M5, utilizado em aproximadamente 99% dos testes anteriores no Work. Preservar cálculo por Last/ticks e conferência M1 conforme regras; o timeframe visual não altera a estratégia.

Entregas consolidadas em ZIP. Instruções devem seguir este caminho: extrair o ZIP na pasta principal do projeto; MT5 > Arquivo > Abrir Pasta de Dados > MQL5; copiar a subpasta de MQL5/Scripts do projeto para Scripts da pasta de dados, e a subpasta de MQL5/Experts para Experts. Informar nome exato das pastas e dos .mq5, compilar com F7 e indicar gráfico, parâmetros, marcador de término e nome/prefixo do relatório. Não exigir instalações fragmentadas dos módulos.

Para acessar relatórios: Windows + R, executar %APPDATA%\MetaQuotes\Terminal\Common\Files. Preservar checkpoints e estados. Diferenciar scripts que terminam sozinhos do EA atual, cujo timer não tem duração máxima e exige remoção manual para encerrar uma observação de 15 minutos. A remoção registra STOP;reason=1;transport=ABSENT, fecha relatório e libera lock.

No uso final, a interface operacional é um EA compilado .ex5. Fontes podem permanecer organizados em .mq5/.mqh, compilados em conjunto; cabeçalhos não são EAs independentes. Coletor/ajuste B3 e arquivos persistentes permanecem dependências de dados/retomada, e não devem ser confundidos com múltiplos EAs.
