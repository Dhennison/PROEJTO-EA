#define main baseline_main
#include "host.cpp"
#undef main
#include "../MQL5/Scripts/ModeloD_Integrado_Sem_Transporte/ModeloD_TestRun.mqh"
int main(){
 std::filesystem::remove_all("/tmp/md615k_host");std::filesystem::create_directories("/tmp/md615k_host");
 RunPreviewIntegrado("MQL5_REGRESSION");bool first=checksPreview==631&&failuresPreview==0;
 RunPreviewIntegrado("MQL5_REGRESSION");bool reproduced=checksPreview==556&&failuresPreview==85;
 Print("NEGATIVE_CONTROL_FIXED_PREFIX;Checks=",checksPreview,";Failures=",failuresPreview,";EXPECTED_REPRODUCTION=",reproduced);
 string first_id,second_id,why;int claim1,claim2;
 if(!MDRegressionRunSuffix(first_id,claim1,why))return 2;
 RunPreviewIntegrado(first_id);bool fresh1=checksPreview==631&&failuresPreview==0;FileClose(claim1);
 if(!MDRegressionRunSuffix(second_id,claim2,why))return 3;
 RunPreviewIntegrado(second_id);bool fresh2=checksPreview==631&&failuresPreview==0;FileClose(claim2);
 bool kept=FileIsExist("ModeloD_TEST_ONLY_615D_PREVIEW_MQL5_REGRESSION.state.tmp",FILE_COMMON);
 Print("REPEATED_REGRESSION;FIRST_631_0=",fresh1,";SECOND_631_0=",fresh2,";UNIQUE_IDS=",first_id!=second_id,";PREVIOUS_FIXTURES_PRESERVED=",kept);
 return first&&reproduced&&fresh1&&fresh2&&first_id!=second_id&&kept?0:1;
}
