#!/usr/bin/env python3
"""Package only the EA and consolidated test include closure, docs and local harness."""
from pathlib import Path
import hashlib
import re
import zipfile

root = Path(__file__).resolve().parents[1]
files = set()
def include_closure(file):
    file = file.resolve()
    if file in files:
        return
    if not file.is_relative_to(root) or not file.is_file():
        raise RuntimeError(f'Invalid dependency: {file}')
    files.add(file)
    for include in re.findall(r'#include\s+"([^"]+)"', file.read_text()):
        include_closure(file.parent / include)
include_closure(root / 'MQL5/Experts/ModeloD_Integrado_Sem_Transporte/EA_ModeloD_Fluxo_Sem_Ordens.mq5')
include_closure(root / 'MQL5/Experts/ModeloD_Integrado_Sem_Transporte/ModeloD_OperationalCases.mqh')
include_closure(root / 'MQL5/Scripts/ModeloD_Integrado_Sem_Transporte/Test_Integrado_Sem_Transporte.mq5')
# Keep runtime and script-local operational modules byte-identical.
for name in ['ModeloD_Operational.mqh', 'ModeloD_OperationalCodec.mqh', 'ModeloD_OperationalFile.mqh', 'ModeloD_OperationalCases.mqh']:
    assert (root / 'MQL5/Experts/ModeloD_Integrado_Sem_Transporte' / name).read_bytes() == (root / 'MQL5/Scripts/ModeloD_Integrado_Sem_Transporte' / name).read_bytes(), name
for file in (root / 'docs').rglob('*'):
    if file.is_file():
        files.add(file)
for name in ['host.cpp', 'integrated.cpp', 'runtime_mock.cpp', 'faults.cpp', 'restart_process.cpp', 'regression_repeat.cpp', 'state_initialization.cpp', 'run_local.py', 'package_delivery.py']:
    files.add(root / 'tests' / name)
files.add(root / 'LEIA_PRIMEIRO.txt')
manifest = ''.join(hashlib.sha256(f.read_bytes()).hexdigest() + '  ' + str(f.relative_to(root)).replace('\\', '/') + '\n' for f in sorted(files))
(root / 'SHA256SUMS.txt').write_text(manifest)
files.add(root / 'SHA256SUMS.txt')
destination = root.parent.parent / 'entregas'
destination.mkdir(exist_ok=True)
output = destination / 'ModeloD_Integrado_Sem_Transporte_v2_06.zip'
with zipfile.ZipFile(output, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(files):
        archive.write(file, 'ModeloD_Integrado_Sem_Transporte/' + str(file.relative_to(root)))
with zipfile.ZipFile(output) as archive:
    assert archive.testzip() is None
    assert len([n for n in archive.namelist() if '/Experts/' in n and n.endswith('.mq5')]) == 1
    assert len([n for n in archive.namelist() if '/Scripts/' in n and n.endswith('.mq5')]) == 1
print(output)
print('Files:', len(files), 'Bytes:', output.stat().st_size)
print('SHA256:', hashlib.sha256(output.read_bytes()).hexdigest())
