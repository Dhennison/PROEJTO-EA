//+------------------------------------------------------------------+
//| DiagTicksAB.mq5  v1.10                                           |
//| Consulta somente leitura: mesma janela, mesmo CopyTicksRange,    |
//| no terminal (A) e no Tester (B). Não envia ordens, não altera    |
//| histórico e não usa nenhuma biblioteca do Modelo D.              |
//|                                                                  |
//| Critério de "tick com flag de negócio" = o mesmo do EA v2.11:    |
//|   flags & (LAST|VOLUME|BUY|SELL) != 0                            |
//| last>0 e volume>0 isolados NÃO provam negócio (podem ser valores |
//| carregados em atualizações de cotação) e são contados à parte.   |
//+------------------------------------------------------------------+
#property version "1.10"

input string   InpSymbol      = "WINZ26";
input datetime InpFrom        = D'2026.10.30 09:00:00'; // hora do servidor
input datetime InpTo          = D'2026.10.30 09:10:00'; // máx. 60 min
input int      InpMaxAttempts = 10;                     // releituras até estabilizar
input string   InpTag         = "";                     // ex.: GENIAL_01, XP_01

#define NF 64
#define NMIN 60

struct Res
  {
   int    n, err, nf, tf_n, carried_n, last_pos, vol_pos;
   long   fv[NF];
   int    fc[NF];
   long   first_tf_msc;
   ulong  hash;                 // hash dos registros com flag de negócio
   int    per_min[NMIN];        // registros com flag de negócio por minuto
   long   first_msc, last_msc;
   double first_last, first_bid, first_ask;
   uint   first_flags;
  };

Res    g_a, g_tr, g_in, g_pa, g_ptr, g_pin;
bool   g_have = false, g_done = false;
int    g_attempt = 0;
string g_out = "";
uint   g_mask = 0;

void Say(const string s) { Print(s); g_out += s + "\r\n"; }

string Clean(const string s)
  {
   string o = "";
   for(int i = 0; i < StringLen(s); i++)
     {
      ushort c = StringGetCharacter(s, i);
      if((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '-')
         o += ShortToString(c);
      else
         o += "_";
     }
   return o;
  }

string Env() { return MQLInfoInteger(MQL_TESTER) ? "TESTER" : "TERMINAL"; }

int OnInit()
  {
   g_mask = (uint)TICK_FLAG_LAST | (uint)TICK_FLAG_VOLUME | (uint)TICK_FLAG_BUY | (uint)TICK_FLAG_SELL;
   if(InpFrom <= 0 || InpTo <= InpFrom || (InpTo - InpFrom) > NMIN * 60)
     { Print("DiagTicksAB: janela inválida (From<To e no máximo 60 min)."); return INIT_PARAMETERS_INCORRECT; }
   if(InpMaxAttempts < 2)
     { Print("DiagTicksAB: InpMaxAttempts deve ser >= 2."); return INIT_PARAMETERS_INCORRECT; }
   if(!SymbolSelect(InpSymbol, true))
     { Print("DiagTicksAB: SymbolSelect falhou para ", InpSymbol, " erro=", GetLastError()); return INIT_FAILED; }
   if(!EventSetTimer(1))
     { Print("DiagTicksAB: EventSetTimer falhou erro=", GetLastError()); return INIT_FAILED; }
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason) { EventKillTimer(); }

void Collect(const uint mode, Res &r)
  {
   r.n = 0; r.err = 0; r.nf = 0; r.tf_n = 0; r.carried_n = 0; r.last_pos = 0; r.vol_pos = 0;
   r.first_tf_msc = 0; r.hash = 1469598103934665603; r.first_msc = 0; r.last_msc = 0;
   r.first_last = 0; r.first_bid = 0; r.first_ask = 0; r.first_flags = 0;
   for(int m = 0; m < NMIN; m++) r.per_min[m] = 0;

   MqlTick t[];
   ulong a = (ulong)InpFrom * 1000;
   ulong b = (ulong)InpTo * 1000 - 1;
   ResetLastError();
   r.n = CopyTicksRange(InpSymbol, t, mode, a, b);
   r.err = GetLastError();
   if(r.n <= 0 || r.n != ArraySize(t)) return;

   r.first_msc = t[0].time_msc; r.last_msc = t[r.n - 1].time_msc;
   r.first_last = t[0].last; r.first_bid = t[0].bid; r.first_ask = t[0].ask; r.first_flags = t[0].flags;

   for(int i = 0; i < r.n; i++)
     {
      int k = -1;
      for(int j = 0; j < r.nf; j++) if(r.fv[j] == (long)t[i].flags) { k = j; break; }
      if(k < 0 && r.nf < NF) { k = r.nf++; r.fv[k] = (long)t[i].flags; r.fc[k] = 0; }
      if(k >= 0) r.fc[k]++;

      if(t[i].last > 0)   r.last_pos++;
      if(t[i].volume > 0) r.vol_pos++;

      bool tf = ((t[i].flags & g_mask) != 0);
      if(tf)
        {
         r.tf_n++;
         if(r.first_tf_msc == 0) r.first_tf_msc = t[i].time_msc;
         int mn = (int)(((ulong)t[i].time_msc - a) / 60000);
         if(mn >= 0 && mn < NMIN) r.per_min[mn]++;
         r.hash ^= (ulong)t[i].time_msc;               r.hash *= 1099511628211;
         r.hash ^= (ulong)MathRound(t[i].last * 100.0); r.hash *= 1099511628211;
         r.hash ^= (ulong)t[i].volume;                  r.hash *= 1099511628211;
         r.hash ^= (ulong)t[i].flags;                   r.hash *= 1099511628211;
        }
      else if(t[i].last > 0 || t[i].volume > 0)
         r.carried_n++;   // last/volume preenchidos SEM flag de negócio (valor carregado)
     }
  }

bool SameRes(const Res &x, const Res &y)
  { return x.n == y.n && x.tf_n == y.tf_n && x.hash == y.hash && x.first_msc == y.first_msc && x.last_msc == y.last_msc; }

void Show(const string tag, const Res &r)
  {
   Say(StringFormat("[%s] n=%d err=%d | flag_negocio(LAST|VOL|BUY|SELL)=%d | carregado_sem_flag=%d | last>0=%d | volume>0=%d | primeiro_neg_msc=%I64d | hash_neg=%I64u",
                    tag, r.n, r.err, r.tf_n, r.carried_n, r.last_pos, r.vol_pos, r.first_tf_msc, r.hash));
   string h = "   flags:";
   for(int j = 0; j < r.nf; j++) h += StringFormat(" %I64d x%d;", r.fv[j], r.fc[j]);
   Say(h);
   string pm = "   neg_por_minuto:";
   int mins = (int)((InpTo - InpFrom) / 60);
   for(int m = 0; m < mins && m < NMIN; m++) pm += StringFormat(" %d", r.per_min[m]);
   Say(pm);
   if(r.n > 0)
      Say(StringFormat("   primeiro_tick: msc=%I64d bid=%.1f ask=%.1f last=%.1f flags=%u | ultimo_msc=%I64d",
                       r.first_msc, r.first_bid, r.first_ask, r.first_last, r.first_flags, r.last_msc));
  }

void Header()
  {
   Say("=== DiagTicksAB v1.10 | ambiente=" + Env() + " | tag=" + InpTag);
   Say("simbolo_consultado=" + InpSymbol + " | simbolo_do_grafico=" + _Symbol + " | periodo=" + EnumToString((ENUM_TIMEFRAMES)_Period));
   Say("janela=" + TimeToString(InpFrom, TIME_DATE | TIME_SECONDS) + " -> " + TimeToString(InpTo, TIME_DATE | TIME_SECONDS) + " (hora do servidor)");
   Say("servidor=" + AccountInfoString(ACCOUNT_SERVER) + " | empresa=" + AccountInfoString(ACCOUNT_COMPANY) + " | build=" + (string)TerminalInfoInteger(TERMINAL_BUILD));
   long cust = 0; SymbolInfoInteger(InpSymbol, SYMBOL_CUSTOM, cust);
   Say(StringFormat("tester=%d visual=%d otimizacao=%d conectado=%d simbolo_custom=%d TimeCurrent=%s",
                    (int)MQLInfoInteger(MQL_TESTER), (int)MQLInfoInteger(MQL_VISUAL_MODE), (int)MQLInfoInteger(MQL_OPTIMIZATION),
                    (int)TerminalInfoInteger(TERMINAL_CONNECTED), (int)cust, TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS)));
  }

void Finish(const bool stable)
  {
   g_done = true;
   string head = g_out; g_out = "";
   Header();
   Say(stable ? "STATUS=ESTAVEL (duas leituras consecutivas identicas, sem erro)"
              : "STATUS=NAO_ESTAVEL_OU_COM_ERRO apos " + IntegerToString(g_attempt) + " tentativas - NAO sustenta conclusao de ausencia de negocios");
   Show("ALL",   g_a);
   Show("TRADE", g_tr);
   Show("INFO",  g_in);
   Say(StringFormat("CRUZAMENTO: ALL.flag_negocio=%d | TRADE.n=%d | TRADE.flag_negocio=%d | hash ALL==TRADE: %s",
                    g_a.tf_n, g_tr.n, g_tr.tf_n, (g_a.hash == g_tr.hash ? "sim" : "nao")));
   Say("--- historico das tentativas ---");
   g_out += head;

   string base = "DiagTicksAB_" + Env() + "_" + Clean(AccountInfoString(ACCOUNT_SERVER)) + "_" + Clean(InpSymbol) + "_" +
                 Clean(TimeToString(InpFrom, TIME_DATE | TIME_MINUTES)) + "_" + Clean(TimeToString(InpTo, TIME_DATE | TIME_MINUTES)) +
                 (InpTag != "" ? "_" + Clean(InpTag) : "") + "_" + (string)GetTickCount64();
   string fn = base + ".txt";
   for(int k = 1; FileIsExist(fn, FILE_COMMON) && k < 100; k++) fn = base + "_" + IntegerToString(k) + ".txt";
   int h = FileOpen(fn, FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h != INVALID_HANDLE) { FileWriteString(h, g_out); FileClose(h); Print("Relatorio gravado em Common\\Files\\", fn); }
   else Print("DiagTicksAB: nao foi possivel gravar o relatorio, erro=", GetLastError());
   ExpertRemove();
  }

void OnTimer()
  {
   if(g_done) return;
   if(TimeCurrent() < InpTo + 2) return;   // no Tester espera o relógio simulado passar da janela

   g_attempt++;
   Collect(COPY_TICKS_ALL,   g_a);
   Collect(COPY_TICKS_TRADE, g_tr);
   Collect(COPY_TICKS_INFO,  g_in);

   bool ok = (g_a.n >= 0 && g_a.err == 0 && g_tr.n >= 0 && g_tr.err == 0 && g_in.n >= 0 && g_in.err == 0);
   bool same = (ok && g_have && SameRes(g_a, g_pa) && SameRes(g_tr, g_ptr) && SameRes(g_in, g_pin));

   Say(StringFormat("tentativa %d | ok=%d | ALL n=%d err=%d tf=%d | TRADE n=%d err=%d | INFO n=%d err=%d | igual_a_anterior=%d",
                    g_attempt, (int)ok, g_a.n, g_a.err, g_a.tf_n, g_tr.n, g_tr.err, g_in.n, g_in.err, (int)same));

   if(same || g_attempt >= InpMaxAttempts) { Finish(same); return; }

   g_have = ok;
   if(ok) { g_pa = g_a; g_ptr = g_tr; g_pin = g_in; }
  }
