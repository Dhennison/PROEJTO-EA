//+------------------------------------------------------------------+
//| DiagTicksAB.mq5 - mesma consulta, dois ambientes                 |
//| Rode (A) anexado a um gráfico do terminal e (B) no Tester com    |
//| "Cada tick baseado em ticks reais". Compare os dois relatórios.  |
//+------------------------------------------------------------------+
#property version "1.00"

input string   InpSymbol = "WINZ26";
input datetime InpFrom   = D'2026.10.30 09:00:00'; // hora do servidor
input datetime InpTo     = D'2026.10.30 09:10:00';

bool   g_done = false;
string g_out  = "";

int OnInit()
  {
   SymbolSelect(InpSymbol, true);
   EventSetTimer(1);
   return INIT_SUCCEEDED;
  }

void OnDeinit(const int reason) { EventKillTimer(); }

void Say(const string s) { Print(s); g_out += s + "\r\n"; }

void Report(const string tag, const uint mode)
  {
   MqlTick t[];
   ulong a = (ulong)InpFrom * 1000;
   ulong b = (ulong)InpTo * 1000 - 1;
   ResetLastError();
   int n = CopyTicksRange(InpSymbol, t, mode, a, b);
   int err = GetLastError();

   long   fv[64]; int fc[64]; int nf = 0;
   int    last_pos = 0, vol_pos = 0, volr_pos = 0, trades = 0;
   long   first_trade_msc = 0;

   for(int i = 0; i < n; i++)
     {
      int k = -1;
      for(int j = 0; j < nf; j++) if(fv[j] == (long)t[i].flags) { k = j; break; }
      if(k < 0 && nf < 64) { k = nf++; fv[k] = (long)t[i].flags; fc[k] = 0; }
      if(k >= 0) fc[k]++;

      if(t[i].last > 0)        last_pos++;
      if(t[i].volume > 0)      vol_pos++;
      if(t[i].volume_real > 0) volr_pos++;
      if(t[i].last > 0 && (t[i].volume > 0 || t[i].volume_real > 0))
        {
         trades++;
         if(first_trade_msc == 0) first_trade_msc = t[i].time_msc;
        }
     }

   Say(StringFormat("[%s] mode=%s n=%d err=%d last>0=%d volume>0=%d volume_real>0=%d trades(last&vol)=%d first_trade_msc=%I64d",
                    (MQLInfoInteger(MQL_TESTER) ? "TESTER" : "TERMINAL"), tag, n, err,
                    last_pos, vol_pos, volr_pos, trades, first_trade_msc));
   string h = "   flags:";
   for(int j = 0; j < nf; j++) h += StringFormat(" %I64d x%d;", fv[j], fc[j]);
   Say(h);
   for(int i = 0; i < MathMin(n, 3); i++)
      Say(StringFormat("   tick[%d] msc=%I64d bid=%.1f ask=%.1f last=%.1f vol=%I64u volr=%.1f flags=%u",
                       i, t[i].time_msc, t[i].bid, t[i].ask, t[i].last, t[i].volume, t[i].volume_real, t[i].flags));
  }

void OnTimer()
  {
   if(g_done) return;
   if(TimeCurrent() < InpTo + 2) return; // no Tester espera o relógio simulado passar da janela
   g_done = true;

   Say("=== DiagTicksAB " + InpSymbol + " " + TimeToString(InpFrom, TIME_SECONDS) + " -> " + TimeToString(InpTo, TIME_SECONDS));
   Say("build=" + (string)TerminalInfoInteger(TERMINAL_BUILD) + " company=" + AccountInfoString(ACCOUNT_COMPANY));
   Report("ALL",   COPY_TICKS_ALL);
   Report("TRADE", COPY_TICKS_TRADE);
   Report("INFO",  COPY_TICKS_INFO);

   string fn = "DiagTicksAB_" + (MQLInfoInteger(MQL_TESTER) ? "TESTER" : "TERMINAL") + ".txt";
   int h = FileOpen(fn, FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_COMMON);
   if(h != INVALID_HANDLE) { FileWriteString(h, g_out); FileClose(h); Print("Relatório: Common\\Files\\", fn); }
   ExpertRemove();
  }
