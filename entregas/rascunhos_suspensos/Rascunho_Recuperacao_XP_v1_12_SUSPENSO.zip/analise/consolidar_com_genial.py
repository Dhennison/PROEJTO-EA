"""Combine separately audited native batches; never fabricate a single native log.
Requires the project checkout (including the v1.11 auditor). User need not run Python.
"""
import argparse,importlib.util,sys,csv,json,hashlib
from pathlib import Path
from decimal import Decimal as D
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'analise'))
from validar_independente import validate

def module(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def combine(base,recovery,out):
 assert not out.exists() or not any(out.iterdir()),'Usar pasta vazia de consolidacao'
 out.mkdir(parents=True,exist_ok=True)
 old=module('auditoria_111',ROOT.parent/'fechamento_agosto_v1_11/analise/analisar_mes.py');new=module('auditoria_112',ROOT/'analise/analisar_mes.py')
 a=old.run(base,out/'genial');b=new.run(recovery,out/'recuperacao')
 va=validate(base,out/'genial');vb=validate(recovery,out/'recuperacao')
 canonical={r['date']:r for r in old.read(base/'REFERENCIAS.csv')}
 for ref in new.read(recovery/'REFERENCIAS.csv'):assert ref==canonical[ref['date']],'Referencia mudou entre fontes'
 daily=[];states=[];issues=[];provenance=[];valid=set();allkeys=set()
 for label,folder,audit in [('GENIAL',base,out/'genial'),('RECUPERACAO',recovery,out/'recuperacao')]:
  log=(folder/'RESULTADO.txt').read_text(encoding='utf-8-sig');first=next(line for line in log.splitlines() if line.startswith('START;'));server=next(x.split('=',1)[1] for x in first.split(';') if x.startswith('servidor='))
  pending={r['data'] for r in old.read(audit/'PENDENCIAS.csv')} if (audit/'PENDENCIAS.csv').exists() else set()
  rows=old.read(audit/'DIARIO_PRINCIPAL.csv') if (audit/'DIARIO_PRINCIPAL.csv').exists() else []
  for r in rows:
   date=r['data'];assert date not in allkeys,'Mesmo dia em duas coletas; nao somar duplicado';allkeys.add(date)
   daily.append(dict(r,fonte=label,servidor=server,lote=folder.name))
   if date.replace('-','.') not in pending:valid.add(date)
  state_file=audit/'TODOS_NIVEIS_QUATRO_CENARIOS.csv'
  for r in old.read(state_file) if state_file.exists() else []:states.append(dict(r,fonte=label,servidor=server))
  for r in old.read(audit/'RESSALVAS.csv') if (audit/'RESSALVAS.csv').exists() else []:issues.append(dict(r,fonte=label,servidor=server))
  provenance.append(dict(source=label,server=server,folder=folder.name,sha256_inputs={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in folder.iterdir() if p.is_file()}))
 expected={d.replace('.','-') for d in old.MAIN_DATES};complete=valid==expected
 assert all(r['data'] in expected for r in daily)
 scenarios=[]
 for model in ('GRADE5_TOQUE','MATEMATICA_TOQUE','GRADE5_ESTRITA','MATEMATICA_ESTRITA'):
  rows=[r for r in states if r['data'] in old.MAIN_DATES and r['cenario']==model]
  assert len({(r['data'],r['nivel']) for r in rows})==len(rows)
  if complete:assert len(rows)==100 and not any(r['estado']=='ABERTA' for r in rows)
  scenarios.append(dict(cenario=model,pontos=str(sum((D(r['pontos']) for r in rows if r['pontos']),D(0))) if complete else None,operacoes=sum(bool(r['hora_entrada']) for r in rows)))
 primary=scenarios[0]['pontos'];result=dict(month='2026-08',complete=complete,Work_points='-387.164995',principal_points=primary,difference=str(D(primary)-D('-387.164995')) if complete else None,pending_Work_dates=sorted(expected-valid),supplement_status=b['supplement_complete'],supplement_points=b['supplement_points'],supplement_Work_points=None,sources=provenance,scenarios=scenarios,independent_states_checked=va['states_checked']+vb['states_checked'],limitations=['Consolidacao de coletas separadas; nao e nova execucao de um so servidor.','Pontos condicionais por negocios recebidos; nao comprovam fila/preenchimento real.','03/08 complementar nao e somado ao comparavel20dias nem recebe Work=0.','Ressalvas de cada fonte sao preservadas; completude absoluta do feed nao certificada.'])
 old.write(out/'DIARIO_PRINCIPAL.csv',sorted(daily,key=lambda r:r['data']));old.write(out/'TODOS_NIVEIS_QUATRO_CENARIOS.csv',states);old.write(out/'RESSALVAS.csv',issues)
 (out/'CONFERENCIA_CONJUNTA.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
 return result
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--base-genial',type=Path,required=True);p.add_argument('--recuperacao',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();r=combine(a.base_genial,a.recuperacao,a.out);print(json.dumps({k:v for k,v in r.items() if k!='sources'},ensure_ascii=False,indent=2))
