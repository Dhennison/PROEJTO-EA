#property strict
#property version "1.00"
#property description "Diagnostico historico fixo 29/10/2026 10:38. SEM ORDENS."
#include "ModeloD_M1DiagnosticCore.mqh"
const string SYMBOL_DIAG="WINZ26";
int reportDiag=INVALID_HANDLE;
bool fileOkDiag=true;
int queryErrorsDiag=0,mismatchDiag=0,structuralDiag=0,rejectedTradeQueries=0;
void LogDiag(string text)
{
 if(reportDiag==INVALID_HANDLE)return;
 ResetLastError();uint n=FileWriteString(reportDiag,text+"\r\n");
 if(n==0||GetLastError()!=0)fileOkDiag=false;
}
string PriceDiag(double p){return DoubleToString(p,8);}
string OHLCtextDiag(const MDOHLCdiag &a)
{return "n="+IntegerToString(a.count)+";invalidos="+IntegerToString(a.invalid)+";O="+PriceDiag(a.open)+";H="+PriceDiag(a.high)+";L="+PriceDiag(a.low)+";C="+PriceDiag(a.close);}
string TickTextDiag(const MqlTick &t)
{return "msc="+IntegerToString(t.time_msc)+";last="+PriceDiag(t.last)+";bid="+PriceDiag(t.bid)+";ask="+PriceDiag(t.ask)+";flags="+IntegerToString((long)t.flags)+";volume="+IntegerToString((long)t.volume)+";volume_real="+PriceDiag(t.volume_real);}
void LogRateDiag(string name,const MqlRates &r)
{
 LogDiag(name+";minuto="+TimeToString(r.time,TIME_DATE|TIME_SECONDS)+";O="+PriceDiag(r.open)+";H="+PriceDiag(r.high)+
 ";L="+PriceDiag(r.low)+";C="+PriceDiag(r.close)+";tick_volume="+IntegerToString(r.tick_volume)+
 ";real_volume="+IntegerToString(r.real_volume)+";spread="+IntegerToString(r.spread));
}
bool RatesDiag(string name,datetime begin,datetime end,MqlRates &rates[])
{
 ArrayFree(rates);ArraySetAsSeries(rates,false);
 ResetLastError();int n=CopyRates(SYMBOL_DIAG,PERIOD_M1,begin,end,rates);int error=GetLastError();
 LogDiag("CONSULTA_M1;nome="+name+";barras="+IntegerToString(n)+";erro="+IntegerToString(error));
 for(int i=0;i<ArraySize(rates);i++)LogRateDiag("M1;consulta="+name,rates[i]);
 if(n<0||error!=0){queryErrorsDiag++;return false;}return true;
}
void CompareTicksDiag(string name,const MqlTick &a[],const MqlTick &b[],bool queriesOk)
{
 int na=ArraySize(a),nb=ArraySize(b),first=-1,limit=na<nb?na:nb;
 for(int i=0;i<limit;i++)if(!MDTickEqDiag(a[i],b[i])){first=i;break;}
 bool equal=na==nb&&first<0;
 LogDiag("COMPARACAO_SEQUENCIA;nome="+name+";consultas_sem_erro="+IntegerToString(queriesOk?1:0)+
 ";quantidade_A="+IntegerToString(na)+";quantidade_B="+IntegerToString(nb)+";delta="+IntegerToString(nb-na)+
 ";sequencia_identica="+IntegerToString(equal?1:0)+";primeira_diferenca="+IntegerToString(first));
 if(first>=0){LogDiag("DIFERENCA_A;"+TickTextDiag(a[first]));LogDiag("DIFERENCA_B;"+TickTextDiag(b[first]));}
 // Igualdade de consultas com erro ou vazias nao e prova de historico completo.
}
bool QueryDiag(string name,datetime begin,int minutes,uint flags,MqlTick &ticks[])
{
 if(IsStopped())return false;
 datetime lastSecond=begin+minutes*60-1;
 long from=(long)begin*1000,to=((long)lastSecond+1)*1000-1;
 MqlRates before[],after[];
 bool beforeOk=RatesDiag(name+"_ANTES",begin,lastSecond,before);
 ArrayFree(ticks);ArraySetAsSeries(ticks,false);
 ResetLastError();int n=CopyTicksRange(SYMBOL_DIAG,ticks,flags,(ulong)from,(ulong)to);int error=GetLastError();
 bool ticksOk=n>=0&&error==0;
 if(!ticksOk)queryErrorsDiag++;
 LogDiag("CONSULTA_TICKS;nome="+name+";de_msc="+IntegerToString(from)+";ate_msc="+IntegerToString(to)+
 ";filtro="+(flags==COPY_TICKS_TRADE?"TRADE":"ALL")+";retornados="+IntegerToString(n)+";erro="+IntegerToString(error));
 bool afterOk=RatesDiag(name+"_DEPOIS",begin,lastSecond,after);
 bool same=ArraySize(before)==ArraySize(after);
 for(int k=0;k<ArraySize(before)&&same;k++)if(!MDRateEqDiag(before[k],after[k]))same=false;
 LogDiag("M1_DURANTE_CONSULTA;nome="+name+";leituras_sem_erro="+IntegerToString(beforeOk&&afterOk?1:0)+";identico="+IntegerToString(same?1:0));
 int total=ArraySize(ticks);
 if(total>2000000){LogDiag("ANALISE_LIMITADA;nome="+name+";mais_de_2000000_registros");queryErrorsDiag++;return false;}
 MDOHLCdiag last[5],changed[5],bid[5],ask[5];long badflags[5];int maxLastIndex[5],maxChangedIndex[5];
 for(int k=0;k<5;k++){MDResetDiag(last[k]);MDResetDiag(changed[k]);MDResetDiag(bid[k]);MDResetDiag(ask[k]);badflags[k]=0;maxLastIndex[k]=-1;maxChangedIndex[k]=-1;}
 int outside=0,regressions=0,rejected=0;long previous=-1;
 uint trade_mask=TICK_FLAG_LAST|TICK_FLAG_VOLUME|TICK_FLAG_BUY|TICK_FLAG_SELL;
 for(int i=0;i<total;i++)
 {
  if(IsStopped())return false;
  MqlTick t=ticks[i];
  string failure=MDClassificarTickDiag(t.time_msc,t.last,t.flags,trade_mask,from,to,previous>=0,previous);
  if(flags==COPY_TICKS_TRADE&&failure!="OK")
  {
   rejected++;
   if(rejected<=3)
   {
    LogDiag("TICK_REJEITADO;consulta="+name+";indice="+IntegerToString(i)+";causa="+failure+";"+TickTextDiag(t));
    if(i>0)LogDiag("TICK_REJEITADO_ANTERIOR;consulta="+name+";indice="+IntegerToString(i-1)+";"+TickTextDiag(ticks[i-1]));
    if(i+1<total)LogDiag("TICK_REJEITADO_SEGUINTE;consulta="+name+";indice="+IntegerToString(i+1)+";"+TickTextDiag(ticks[i+1]));
   }
  }
  if(previous>=0&&t.time_msc<previous)
  {
   regressions++;
   if(regressions<=3){LogDiag("REGRESSAO;nome="+name+";indice="+IntegerToString(i));LogDiag("ANTERIOR;"+TickTextDiag(ticks[i-1]));LogDiag("ATUAL;"+TickTextDiag(t));}
  }
  previous=t.time_msc;
  if(t.time_msc<from||t.time_msc>to)
  {outside++;if(outside<=3)LogDiag("FORA_JANELA;nome="+name+";indice="+IntegerToString(i)+";"+TickTextDiag(t));continue;}
  int minute=(int)((t.time_msc-from)/60000);
  if(minute<0||minute>=minutes||minute>=5){outside++;continue;}
  MDPushDiag(last[minute],t.last);MDPushDiag(bid[minute],t.bid);MDPushDiag(ask[minute],t.ask);
  if(MathIsValidNumber(t.last)&&t.last>0&&(maxLastIndex[minute]<0||t.last>ticks[maxLastIndex[minute]].last))maxLastIndex[minute]=i;
  if((t.flags&TICK_FLAG_LAST)!=0){MDPushDiag(changed[minute],t.last);if(MathIsValidNumber(t.last)&&t.last>0&&(maxChangedIndex[minute]<0||t.last>ticks[maxChangedIndex[minute]].last))maxChangedIndex[minute]=i;}
  if((t.flags&trade_mask)==0)badflags[minute]++;
 }
 if(total>0){LogDiag("PRIMEIRO;nome="+name+";"+TickTextDiag(ticks[0]));LogDiag("ULTIMO;nome="+name+";"+TickTextDiag(ticks[total-1]));}
 LogDiag("ESTRUTURA;nome="+name+";regressoes="+IntegerToString(regressions)+";fora_janela="+IntegerToString(outside)+";ticks_rejeitados="+IntegerToString(rejected));
 if(flags==COPY_TICKS_TRADE&&rejected>0)rejectedTradeQueries++;
 if(regressions>0||outside>0)structuralDiag++;
 for(int k=0;k<minutes;k++)
 {
  datetime minuteTime=begin+k*60;string tag="consulta="+name+";minuto="+TimeToString(minuteTime,TIME_DATE|TIME_SECONDS);
  LogDiag("TICKS_LAST;"+tag+";"+OHLCtextDiag(last[k])+";sem_flag_negocio_aceita="+IntegerToString(badflags[k]));
  LogDiag("TICKS_SOMENTE_FLAG_LAST;"+tag+";"+OHLCtextDiag(changed[k]));
  if(maxLastIndex[k]>=0)LogDiag("TICK_MAX_LAST;"+tag+";indice="+IntegerToString(maxLastIndex[k])+";"+TickTextDiag(ticks[maxLastIndex[k]]));
  if(maxChangedIndex[k]>=0)LogDiag("TICK_MAX_FLAG_LAST;"+tag+";indice="+IntegerToString(maxChangedIndex[k])+";"+TickTextDiag(ticks[maxChangedIndex[k]]));
  if(flags==COPY_TICKS_ALL){LogDiag("TICKS_BID;"+tag+";"+OHLCtextDiag(bid[k]));LogDiag("TICKS_ASK;"+tag+";"+OHLCtextDiag(ask[k]));}
  int found=-1,matches=0;
  for(int j=0;j<ArraySize(after);j++)if(after[j].time==minuteTime){found=j;matches++;}
  if(matches!=1){LogDiag("COMPARACAO_M1;"+tag+";status=M1_AUSENTE_OU_DUPLICADO");queryErrorsDiag++;continue;}
  MqlRates bar=after[found];
  bool comparable=ticksOk&&afterOk&&last[k].count>0&&last[k].invalid==0&&regressions==0&&outside==0&&(flags!=COPY_TICKS_TRADE||badflags[k]==0);
  bool agrees=MDMatchDiag(last[k],bar);
  LogDiag("COMPARACAO_M1;"+tag+";comparavel="+IntegerToString(comparable?1:0)+";OHLC_Last_confere="+IntegerToString(agrees?1:0)+
   ";O_confere="+IntegerToString(MDPriceEqDiag(last[k].open,bar.open)?1:0)+";H_confere="+IntegerToString(MDPriceEqDiag(last[k].high,bar.high)?1:0)+
   ";L_confere="+IntegerToString(MDPriceEqDiag(last[k].low,bar.low)?1:0)+";C_confere="+IntegerToString(MDPriceEqDiag(last[k].close,bar.close)?1:0));
  // Somente TRADE e a comparacao principal. ALL/Bid/Ask sao alternativas diagnosticas.
  if(flags==COPY_TICKS_TRADE&&comparable&&!agrees)mismatchDiag++;
 }
 return ticksOk&&beforeOk&&afterOk;
}
void OnStart()
{
 string stamp=TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS);
 StringReplace(stamp,".","");StringReplace(stamp,":","");StringReplace(stamp," ","_");
 string filename="ModeloD_Diagnostico_Ticks_1038_20261029_EXEC_"+stamp+"_"+IntegerToString((long)GetTickCount64())+".txt";
 reportDiag=FileOpen(filename,FILE_WRITE|FILE_TXT|FILE_ANSI|FILE_COMMON|FILE_SHARE_READ,0,CP_UTF8);
 if(reportDiag==INVALID_HANDLE){Print("DIAG_M1_ERRO_ABRIR_RELATORIO;erro=",GetLastError());return;}
 Print("DIAG_M1_INICIO;data_fixa=20261029;incidente=10:38;contrato=WINZ26;SEM_ORDENS;detalhes_apenas_no_TXT");
 LogDiag("DIAG_M1_INICIO;versao=1.00;data_fixa=20261029;janela=10:35-10:40;incidente=10:38;contrato=WINZ26;SEM_ORDENS;NAO_USA_AJUSTE_B3");
 LogDiag("AMBIENTE;build="+IntegerToString(TerminalInfoInteger(TERMINAL_BUILD))+";servidor="+AccountInfoString(ACCOUNT_SERVER)+
 ";conectado="+IntegerToString(TerminalInfoInteger(TERMINAL_CONNECTED))+";hora_local="+TimeToString(TimeLocal(),TIME_DATE|TIME_SECONDS));
 if(!SymbolSelect(SYMBOL_DIAG,true))
 {
  LogDiag("ERRO;WINZ26_INDISPONIVEL;erro="+IntegerToString(GetLastError()));queryErrorsDiag++;
 }
 else
 {
  long chartMode=-1;bool chartModeOk=SymbolInfoInteger(SYMBOL_DIAG,SYMBOL_CHART_MODE,chartMode);
  LogDiag("SIMBOLO;chart_mode_lido="+IntegerToString(chartModeOk?1:0)+";chart_mode="+IntegerToString(chartMode)+";0=BID;1=LAST");
  MqlTick wideA[],wideB[],minuteA[],minuteB[],allA[],allB[],part[];
  bool wa=false,wb=false,ma=false,mb=false,aa=false,ab=false;
  datetime window=D'2026.10.29 10:35:00',incident=D'2026.10.29 10:38:00';
  for(int round=0;round<2&&!IsStopped();round++)
  {
   string label=round==0?"A":"B";
   Print("DIAG_M1_PROGRESSO;rodada=",label,";trecho=10h35_a_10h40");
   if(round==0)wa=QueryDiag(label+"_CINCO_MINUTOS",window,5,COPY_TICKS_TRADE,wideA);
   else wb=QueryDiag(label+"_CINCO_MINUTOS",window,5,COPY_TICKS_TRADE,wideB);
   int offset=0;bool identical=true,partsOk=true;
   for(int k=0;k<5&&!IsStopped();k++)
   {
    bool ok=QueryDiag(label+"_MINUTO_"+IntegerToString(k),window+k*60,1,COPY_TICKS_TRADE,part);
    if(!ok)partsOk=false;
    int nw=round==0?ArraySize(wideA):ArraySize(wideB);
    for(int i=0;i<ArraySize(part);i++)
    {
     if(offset>=nw)identical=false;
     else if(round==0){if(!MDTickEqDiag(wideA[offset],part[i]))identical=false;}
     else {if(!MDTickEqDiag(wideB[offset],part[i]))identical=false;}
     offset++;
    }
   }
   int nw=round==0?ArraySize(wideA):ArraySize(wideB);
   LogDiag("COMPARACAO_MINUTOS;rodada="+label+";total_minutos="+IntegerToString(offset)+";total_bloco="+IntegerToString(nw)+
    ";consultas_sem_erro="+IntegerToString(partsOk&&(round==0?wa:wb)?1:0)+";sequencia_identica="+IntegerToString(identical&&offset==nw?1:0));
   Print("DIAG_M1_PROGRESSO;rodada=",label,";trecho=10h38_a_10h39");
   if(round==0){ma=QueryDiag("A_1038_TRADE",incident,1,COPY_TICKS_TRADE,minuteA);aa=QueryDiag("A_1038_ALL",incident,1,COPY_TICKS_ALL,allA);}
   else {mb=QueryDiag("B_1038_TRADE",incident,1,COPY_TICKS_TRADE,minuteB);ab=QueryDiag("B_1038_ALL",incident,1,COPY_TICKS_ALL,allB);}
   if(round==0&&!IsStopped())Sleep(2000);
  }
  if(!IsStopped())
  {
   CompareTicksDiag("10h35_10h40_A_VS_B",wideA,wideB,wa&&wb);
   CompareTicksDiag("10h38_TRADE_A_VS_B",minuteA,minuteB,ma&&mb);
   CompareTicksDiag("10h38_ALL_A_VS_B",allA,allB,aa&&ab);
  }
 }
 string summary="DIAG_M1_FIM;interrompido="+IntegerToString(IsStopped()?1:0)+";consultas_com_erro_ou_limite="+IntegerToString(queryErrorsDiag)+
 ";consultas_TRADE_com_tick_rejeitado="+IntegerToString(rejectedTradeQueries)+";comparacoes_TRADE_M1_divergentes="+IntegerToString(mismatchDiag)+";consultas_com_regressao_ou_fora_janela="+IntegerToString(structuralDiag)+
 ";NAO_CERTIFICA_INTEGRIDADE_NEM_LIBERA_EA;SEM_ORDENS";
 LogDiag(summary);ResetLastError();FileFlush(reportDiag);if(GetLastError()!=0)fileOkDiag=false;
 FileClose(reportDiag);reportDiag=INVALID_HANDLE;
 Print(summary);
 Print("RELATORIO_M1_FECHADO;",TerminalInfoString(TERMINAL_COMMONDATA_PATH),"\\Files\\",filename);
 if(!fileOkDiag)Print("DIAG_M1_FALHA_GRAVACAO;ENVIAR_TAMBEM_MENSAGENS_DA_ABA_EXPERTS");
}
