#ifndef MD_M1_DIAGNOSTIC_CORE
#define MD_M1_DIAGNOSTIC_CORE
// Analise pura. Preserva ordem e multiplicidade recebidas; nao ordena nem deduplica.
struct MDOHLCdiag
{
 long count,invalid;double open,high,low,close;
};
void MDResetDiag(MDOHLCdiag &a)
{a.count=0;a.invalid=0;a.open=0;a.high=0;a.low=0;a.close=0;}
void MDPushDiag(MDOHLCdiag &a,double p)
{
 if(!MathIsValidNumber(p)||p<=0){a.invalid++;return;}
 if(a.count==0){a.open=p;a.high=p;a.low=p;}
 if(p>a.high){a.high=p;}
 if(p<a.low){a.low=p;}
 a.close=p;a.count++;
}
bool MDPriceEqDiag(double a,double b)
{return MathIsValidNumber(a)&&MathIsValidNumber(b)&&MathAbs(a-b)<0.0000001;}
bool MDMatchDiag(const MDOHLCdiag &a,const MqlRates &b)
{return a.count>0&&a.invalid==0&&MDPriceEqDiag(a.open,b.open)&&MDPriceEqDiag(a.high,b.high)&&MDPriceEqDiag(a.low,b.low)&&MDPriceEqDiag(a.close,b.close);}
bool MDTickEqDiag(const MqlTick &a,const MqlTick &b)
{return a.time==b.time&&a.time_msc==b.time_msc&&a.bid==b.bid&&a.ask==b.ask&&a.last==b.last&&a.volume==b.volume&&a.volume_real==b.volume_real&&a.flags==b.flags;}
bool MDRateEqDiag(const MqlRates &a,const MqlRates &b)
{return a.time==b.time&&a.open==b.open&&a.high==b.high&&a.low==b.low&&a.close==b.close&&a.tick_volume==b.tick_volume&&a.real_volume==b.real_volume&&a.spread==b.spread;}
// Equivalente aos predicados do bloco observacional; nao corrige nem reordena.
string MDClassificarTickDiag(long msc,double last,uint flags,uint mask,long from,long end,bool has_previous,long previous)
{
 if((flags&mask)==0)return "FLAGS_SEM_NEGOCIO";
 if(msc<from||msc>end)return "FORA_DA_JANELA";
 if(!MathIsValidNumber(last)||last<=0)return "LAST_INVALIDO";
 if(has_previous&&msc<previous)return "CRONOLOGIA_REGRESSIVA";
 return "OK";
}
#endif
